# Individual progress report

This folder is a self-contained, vanilla HTML/CSS/JS site: Sumatra's individual Milestone 1
progress report for the team — the codebase modernization journey, the Week 2–6 OOP design
walkthrough, the two design corrections caught along the way, and the use case diagram.

No build step, no dependencies. It's meant to be opened directly or served as a static site.

**Live at:** <https://kainos-payroll-documentation.lr-drsumatra.workers.dev/>, hosted on
Cloudflare under a separate Cloudflare account — chosen over GitHub Pages specifically because
this repo is private and GitHub Pages on a private repo needs a paid GitHub plan, while
Cloudflare has no such restriction.

## Preview locally

```bash
cd docs
python3 -m http.server 8000
# open http://localhost:8000
```

## Redeploying to Cloudflare

The live site is a **Direct Upload** (no GitHub connection), so it does not auto-deploy on
push — it has to be re-uploaded by hand after any change:

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) → **Workers & Pages** →
   `kainos-payroll-documentation`.
2. Click **Create deployment** (or **Upload assets**, depending on the current dashboard).
3. Upload the **contents of this `docs/` folder** (not the folder itself as a wrapper —
   `index.html` needs to land at the upload root).
4. Deploy. The `*.workers.dev` URL stays the same across redeploys.

If this ever needs to switch to auto-deploy-on-push instead, Cloudflare Pages can also connect
directly to a private GitHub repo (via the Cloudflare Pages GitHub App) with build output
directory set to `docs` and no build command.

**Optional: gating it with Cloudflare Access.** Since the `*.workers.dev` URL is otherwise
publicly reachable by anyone with the link, an Access policy (Zero Trust → Access →
Applications) can require email/SSO verification before anyone can view it — worth considering
if this shouldn't be open to the whole internet, not just off search engines.

## Structure

```
docs/
├── index.html              the whole page
├── assets/
│   ├── css/style.css       design tokens mirror src/ui/Theme.java exactly
│   ├── js/main.js          tabs, scroll-spy, hamburger menu, theme toggle, UCD lightbox
│   ├── fonts/              kinetika-bold.ttf, the same display font the Swing app uses
│   └── img/
│       ├── ucd.svg             the revised (rev2) use case diagram
│       ├── kainos-logo*.png    the Kainos leaf mark (nav brand + favicon + collage tile)
│       └── screens/            real screenshots captured from the running Swing app,
│                                used in the hero collage
```

## Updating content

Everything is hand-written in `index.html` — there's no CMS or data file. If the design
worksheet changes again (e.g. after Week 6 team consolidation), the "Design corrections" and
"Class hierarchy" sections should be re-checked against the current workbook so this page
doesn't drift out of sync with it, the same way `README.md`'s OOP design section needs to stay
in sync.
