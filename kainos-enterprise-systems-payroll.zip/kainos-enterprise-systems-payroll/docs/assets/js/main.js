(function () {
  "use strict";

  /* ---------- theme toggle (persisted per-viewer, local only) ---------- */
  var root = document.documentElement;
  var themeBtn = document.getElementById("themeToggle");

  function applyTheme(mode) {
    if (mode === "dark" || mode === "light") {
      root.setAttribute("data-theme", mode);
    } else {
      root.removeAttribute("data-theme");
    }
    if (themeBtn) {
      var isDark =
        mode === "dark" ||
        (!mode && window.matchMedia("(prefers-color-scheme: dark)").matches);
      themeBtn.textContent = isDark ? "☀" : "☽";
    }
  }

  var savedTheme = null;
  try {
    savedTheme = localStorage.getItem("motorph-docs-theme");
  } catch (e) {
    /* private mode / blocked storage - ignore, default theme applies */
  }
  applyTheme(savedTheme);

  if (themeBtn) {
    themeBtn.addEventListener("click", function () {
      var current = root.getAttribute("data-theme");
      var isDark =
        current === "dark" ||
        (!current && window.matchMedia("(prefers-color-scheme: dark)").matches);
      var next = isDark ? "light" : "dark";
      applyTheme(next);
      try {
        localStorage.setItem("motorph-docs-theme", next);
      } catch (e) {
        /* ignore - not essential */
      }
    });
  }

  /* ---------- hamburger menu (phones + tablets) ---------- */
  var menuToggle = document.getElementById("menuToggle");
  var mobileMenu = document.getElementById("mobileMenu");

  function closeMobileMenu() {
    if (!menuToggle || !mobileMenu) return;
    mobileMenu.classList.remove("open");
    menuToggle.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  }

  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener("click", function () {
      var isOpen = mobileMenu.classList.toggle("open");
      menuToggle.classList.toggle("open", isOpen);
      menuToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    mobileMenu.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", closeMobileMenu);
    });

    document.addEventListener("click", function (e) {
      if (
        mobileMenu.classList.contains("open") &&
        !mobileMenu.contains(e.target) &&
        !menuToggle.contains(e.target)
      ) {
        closeMobileMenu();
      }
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeMobileMenu();
    });
  }

  /* ---------- scroll-spy nav ---------- */
  var navLinks = Array.prototype.slice.call(
    document.querySelectorAll(".navlinks a, .mobile-menu a")
  );
  var sections = navLinks
    .map(function (a) {
      var id = a.getAttribute("href").slice(1);
      return document.getElementById(id);
    })
    .filter(Boolean);

  if ("IntersectionObserver" in window && sections.length) {
    var spy = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var id = entry.target.id;
            navLinks.forEach(function (a) {
              a.classList.toggle("active", a.getAttribute("href") === "#" + id);
            });
          }
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach(function (s) {
      spy.observe(s);
    });
  }

  /* ---------- reveal on scroll ---------- */
  var revealEls = Array.prototype.slice.call(document.querySelectorAll(".reveal"));
  if ("IntersectionObserver" in window && revealEls.length) {
    var reveal = new IntersectionObserver(
      function (entries, obs) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("in");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -10% 0px" }
    );
    revealEls.forEach(function (el) {
      reveal.observe(el);
    });
    // safety net: never let content stay invisible - if something keeps an
    // element from ever registering as intersecting (slow devices, an
    // unusual viewport, a screenshot/print tool), force it visible anyway.
    window.setTimeout(function () {
      revealEls.forEach(function (el) {
        el.classList.add("in");
      });
    }, 2500);
  } else {
    revealEls.forEach(function (el) {
      el.classList.add("in");
    });
  }

  /* ---------- week tabs ---------- */
  var tabBtns = Array.prototype.slice.call(document.querySelectorAll(".tab-btn"));
  var tabPanels = Array.prototype.slice.call(document.querySelectorAll(".tab-panel"));

  tabBtns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var target = btn.getAttribute("data-tab");
      tabBtns.forEach(function (b) {
        b.classList.toggle("active", b === btn);
      });
      tabPanels.forEach(function (p) {
        p.classList.toggle("active", p.id === target);
      });
    });
  });

  /* ---------- class hierarchy toggle ---------- */
  var hierBtns = Array.prototype.slice.call(document.querySelectorAll(".hierarchy-toggle .tab-btn"));
  var hierTrees = Array.prototype.slice.call(document.querySelectorAll(".hier-tree"));

  hierBtns.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var target = btn.getAttribute("data-hier");
      hierBtns.forEach(function (b) {
        b.classList.toggle("active", b === btn);
      });
      hierTrees.forEach(function (t) {
        t.classList.toggle("active", t.id === target);
      });
    });
  });

  /* ---------- UCD lightbox ---------- */
  var ucdFrame = document.getElementById("ucdFrame");
  var lightbox = document.getElementById("lightbox");
  var lightboxImg = document.getElementById("lightboxImg");
  var lightboxClose = document.getElementById("lightboxClose");

  function openLightbox() {
    if (!lightbox || !lightboxImg || !ucdFrame) return;
    var src = ucdFrame.querySelector("img").getAttribute("src");
    lightboxImg.setAttribute("src", src);
    lightbox.classList.add("open");
    document.body.style.overflow = "hidden";
  }

  function closeLightbox() {
    if (!lightbox) return;
    lightbox.classList.remove("open");
    document.body.style.overflow = "";
  }

  if (ucdFrame) {
    ucdFrame.addEventListener("click", openLightbox);
  }
  if (lightboxClose) {
    lightboxClose.addEventListener("click", closeLightbox);
  }
  if (lightbox) {
    lightbox.addEventListener("click", function (e) {
      if (e.target === lightbox) closeLightbox();
    });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeLightbox();
  });

  /* ---------- hero collage parallax ---------- */
  // tilts the whole stack toward the cursor; each card keeps its own
  // independent float animation, so this only ever touches the container
  var collage = document.querySelector(".hero-collage");
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (collage && !reduceMotion && window.matchMedia("(hover: hover)").matches) {
    collage.addEventListener("mousemove", function (e) {
      var rect = collage.getBoundingClientRect();
      var relX = (e.clientX - rect.left) / rect.width - 0.5; // -0.5..0.5
      var relY = (e.clientY - rect.top) / rect.height - 0.5;
      var rotateY = relX * 8;
      var rotateX = relY * -8;
      collage.style.transform = "rotateX(" + rotateX.toFixed(2) + "deg) rotateY(" + rotateY.toFixed(2) + "deg)";
    });

    collage.addEventListener("mouseleave", function () {
      collage.style.transform = "rotateX(0deg) rotateY(0deg)";
    });
  }

  /* ---------- footer year ---------- */
  var yearEl = document.getElementById("year");
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
})();
