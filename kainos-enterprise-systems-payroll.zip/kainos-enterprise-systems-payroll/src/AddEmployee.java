import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.util.List;
import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;
import dao.EmployeeRepository;
import dao.CsvEmployeeRepository;
import model.Employee;
import ui.Theme;
import util.FontUtil;



public class AddEmployee extends ui.AppFrame {

    private final EmployeeRepository employeeRepository = new CsvEmployeeRepository();

    public AddEmployee() {
        initComponents();

    // Ask the handler for the next available ID
    int nextId = employeeRepository.nextEmployeeNumber();
    jTxtEmpNum.setText(String.valueOf(nextId));

    // Keep it non-editable so users can't break the ID sequence
    jTxtEmpNum.setEditable(false);
    jTxtEmpNum.setFocusable(false);
    jTxtEmpNum.setBackground(java.awt.Color.LIGHT_GRAY);
}

    // build the add-employee form
    private void initComponents() {
        setTitle("Add New Employee");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTxtEmpNum = new JTextField();
        jTxtLastName = new JTextField();
        jTxtFirstName = new JTextField();
        jTxtPhoneNumber = new JTextField();
        jTxtStatus = new JTextField("Regular");
        jTxtPosition = new JTextField();
        jTextSSS = new JTextField();
        jTextPHILHEALTH = new JTextField();
        jTextTIN = new JTextField();
        jTextPAGIBIG = new JTextField();
        jButtonSubmit = new JButton("Submit");
        jButtonCancel = new JButton("Close");

        jButtonSubmit.addActionListener(this::jButtonSubmitActionPerformed);
        jButtonCancel.addActionListener(this::jButtonCancelActionPerformed);
        jButtonSubmit.setBackground(Theme.NAVY);
        jButtonSubmit.setForeground(Color.WHITE);
        jButtonSubmit.putClientProperty("JButton.buttonType", "default");

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        int row = 0;
        row = addSectionHeader(form, "Personal Information", row);
        row = addField(form, "Employee Number", jTxtEmpNum, row);
        row = addField(form, "Last Name", jTxtLastName, row);
        row = addField(form, "First Name", jTxtFirstName, row);
        row = addField(form, "Phone Number", jTxtPhoneNumber, row);
        row = addField(form, "Status", jTxtStatus, row);
        row = addField(form, "Position", jTxtPosition, row);
        row = addSectionHeader(form, "Government IDs", row);
        row = addField(form, "SSS", jTextSSS, row);
        row = addField(form, "PhilHealth", jTextPHILHEALTH, row);
        row = addField(form, "TIN", jTextTIN, row);
        row = addField(form, "Pag-IBIG", jTextPAGIBIG, row);

        JPanel buttonRow = new JPanel();
        buttonRow.setLayout(new BoxLayout(buttonRow, BoxLayout.X_AXIS));
        buttonRow.setOpaque(false);
        buttonRow.add(Box.createHorizontalGlue());
        buttonRow.add(jButtonSubmit);
        buttonRow.add(Box.createHorizontalStrut(10));
        buttonRow.add(jButtonCancel);

        JLabel credits = new JLabel(Theme.CREDITS);
        credits.setForeground(Theme.TEXT_MUTED);
        credits.setFont(credits.getFont().deriveFont(11f));

        JPanel buttons = new JPanel(new BorderLayout());
        buttons.setBorder(BorderFactory.createEmptyBorder(4, 28, 12, 28));
        buttons.add(credits, BorderLayout.WEST);
        buttons.add(buttonRow, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout());
        content.add(buildBrandStrip(), BorderLayout.WEST);
        content.add(form, BorderLayout.CENTER);
        content.add(buttons, BorderLayout.SOUTH);

        setContentPane(content);
        setMinimumSize(new Dimension(640, 620));
        pack();
    }

    private JPanel buildBrandStrip() {
        JPanel strip = new JPanel(new GridBagLayout());
        strip.setBackground(Theme.NAVY);
        strip.setPreferredSize(new Dimension(200, 10));
        JLabel wordmark = new JLabel("MotorPH");
        wordmark.setForeground(Color.WHITE);
        wordmark.setFont(FontUtil.getKinetikaFont(28f));
        strip.add(wordmark);
        return strip;
    }

    private static int addSectionHeader(JPanel form, String text, int row) {
        JLabel header = new JLabel(text);
        header.setFont(header.getFont().deriveFont(Font.BOLD, 14f));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(row == 0 ? 0 : 18, 0, 8, 0);
        form.add(header, c);
        return row + 1;
    }

    private static int addField(JPanel form, String label, JTextField field, int row) {
        GridBagConstraints lc = new GridBagConstraints();
        lc.gridx = 0;
        lc.gridy = row;
        lc.anchor = GridBagConstraints.WEST;
        lc.insets = new Insets(4, 0, 4, 12);
        form.add(new JLabel(label), lc);

        GridBagConstraints fc = new GridBagConstraints();
        fc.gridx = 1;
        fc.gridy = row;
        fc.weightx = 1;
        fc.fill = GridBagConstraints.HORIZONTAL;
        fc.insets = new Insets(4, 0, 4, 0);
        field.setPreferredSize(new Dimension(240, field.getPreferredSize().height));
        form.add(field, fc);
        return row + 1;
    }


    private void jTxtEmpNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtEmpNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtEmpNumActionPerformed

    private void jTextSSSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextSSSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextSSSActionPerformed

    private void jButtonSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSubmitActionPerformed
        try {
        // Create the Employee object using the names currently in your AddEmployee.txt
        Employee newEmp = new Employee(
            Integer.parseInt(jTxtEmpNum.getText()), 
            jTxtLastName.getText().trim(),
            jTxtFirstName.getText().trim(),
            jTxtPhoneNumber.getText().trim(),
            "Regular", // Temporarily hardcoded because jComboStatus was missing
            jTxtPosition.getText().trim(),
            "N/A",     // Temporarily hardcoded because jTxtSupervisor was missing
            "N/A",     // Temporarily hardcoded because jTxtAddress was missing
            jTextSSS.getText().trim(),
            jTextPHILHEALTH.getText().trim(),
            jTextTIN.getText().trim(),
            jTextPAGIBIG.getText().trim(),
            0.0, // Basic Salary (Update this name if you find it in Design view)
            0.0, // Rice Subsidy
            0.0, // Phone Allowance
            0.0, // Clothing Allowance
            0.0, // Gross Semi-monthly
            0.0, // Hourly Rate
            0.0, // Withholding Tax
            "01/01/1990" // Birthday
        );

        employeeRepository.add(newEmp);

        JOptionPane.showMessageDialog(this, "Employee Added Successfully!");
        
        if (EmployeeTable.getInstance() != null) {
            EmployeeTable.getInstance().loadEmployeeData();
        }
        this.dispose();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
    }//GEN-LAST:event_jButtonSubmitActionPerformed

    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        // TODO add your handling code here:
    dispose(); 
    }//GEN-LAST:event_jButtonCancelActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddEmployee().setVisible(true);
            }
        });
    }

    private JButton jButtonCancel;
    private JButton jButtonSubmit;
    private JTextField jTextPAGIBIG;
    private JTextField jTextPHILHEALTH;
    private JTextField jTextSSS;
    private JTextField jTextTIN;
    private JTextField jTxtEmpNum;
    private JTextField jTxtFirstName;
    private JTextField jTxtLastName;
    private JTextField jTxtPhoneNumber;
    private JTextField jTxtPosition;
    private JTextField jTxtStatus;
}
