package dao;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;
import java.io.*;
import java.util.*;
import model.User;
import util.AppPaths;
import util.PasswordHasher;

/**
 * CSV-file-backed implementation of UserRepository.
 * Implements encapsulation by hiding CSV column indices and file paths.
 */
public class CsvUserRepository implements UserRepository {

    private final String loginFile = AppPaths.dataFile("employee_logins.csv").getPath();
    private static final int COL_EMP_ID = 0;
    private static final int COL_LAST_NAME = 1;
    private static final int COL_FIRST_NAME = 2;
    private static final int COL_USERNAME = 5;
    private static final int COL_PASSWORD = 6;
    private static final int COL_SEC_QUESTION = 7;
    private static final int COL_SEC_ANSWER = 8;
    private static final int COL_ROLE = 9;
    private static final int COL_EMAIL = 10;

    /**
     * Authenticates user and returns a User object if successful.
     * Passwords are stored as salted PBKDF2 hashes; a legacy plaintext
     * password that still matches gets transparently upgraded in place.
     */
    @Override
    public User authenticate(String username, String password) {
        try (CSVReader reader = new CSVReader(new FileReader(loginFile))) {
            String[] row;
            reader.readNext(); // Skip header

            while ((row = reader.readNext()) != null) {
                if (row.length > COL_PASSWORD && row[COL_USERNAME].trim().equals(username)) {
                    String storedPassword = row[COL_PASSWORD].trim();
                    boolean matches = PasswordHasher.isHashed(storedPassword)
                            ? PasswordHasher.matches(password, storedPassword)
                            : storedPassword.equals(password);

                    if (!matches) {
                        return null;
                    }
                    if (!PasswordHasher.isHashed(storedPassword)) {
                        updatePassword(row[COL_EMP_ID].trim(), password);
                    }
                    return mapRowToUser(row);
                }
            }
        } catch (IOException | CsvException e) {
            System.err.println("Database Error: " + e.getMessage());
        }
        return null;
    }

    @Override
    public String getSecurityQuestion(String empId) {
        try (CSVReader reader = new CSVReader(new FileReader(loginFile))) {
            String[] row;
            reader.readNext(); // Skip header
            while ((row = reader.readNext()) != null) {
                if (row.length > COL_SEC_QUESTION && row[COL_EMP_ID].trim().equals(empId)) {
                    return row[COL_SEC_QUESTION].trim();
                }
            }
        } catch (IOException | CsvException e) {
            System.err.println("Error reading question: " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean verifySecurityAnswer(String empId, String inputAnswer) {
        try (CSVReader reader = new CSVReader(new FileReader(loginFile))) {
            String[] row;
            reader.readNext(); // Skip header
            while ((row = reader.readNext()) != null) {
                if (row.length > COL_SEC_ANSWER && row[COL_EMP_ID].trim().equals(empId)) {
                    return row[COL_SEC_ANSWER].trim().equalsIgnoreCase(inputAnswer.trim());
                }
            }
        } catch (IOException | CsvException e) {
            System.err.println("Error verifying answer: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updatePassword(String empId, String newPassword) {
        List<String[]> allRows = readAllRows();
        boolean found = false;
        String hashed = PasswordHasher.hash(newPassword);

        for (String[] row : allRows) {
            if (row.length > COL_PASSWORD && row[COL_EMP_ID].trim().equals(empId)) {
                row[COL_PASSWORD] = hashed;
                found = true;
                break;
            }
        }

        return found && writeAllRows(allRows);
    }

    private User mapRowToUser(String[] row) {
        String email = row.length > COL_EMAIL ? row[COL_EMAIL].trim() : null;
        return new User(
            row[COL_EMP_ID].trim(),
            row[COL_FIRST_NAME].trim(),
            row[COL_LAST_NAME].trim(),
            row[COL_USERNAME].trim(),
            row[COL_PASSWORD].trim(),
            row[COL_ROLE].trim(),
            email
        );
    }

    private List<String[]> readAllRows() {
        List<String[]> rows = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(loginFile))) {
            rows.addAll(reader.readAll());
        } catch (IOException | CsvException e) {
            System.err.println("Error reading CSV: " + e.getMessage());
        }
        return rows;
    }

    private boolean writeAllRows(List<String[]> rows) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(loginFile))) {
            writer.writeAll(rows);
            return true;
        } catch (IOException e) {
            System.err.println("Error writing CSV: " + e.getMessage());
            return false;
        }
    }
}
