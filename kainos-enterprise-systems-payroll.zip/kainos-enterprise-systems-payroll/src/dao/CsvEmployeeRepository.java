package dao;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;
import java.io.*;
import java.util.*;
import model.Employee;
import util.AppPaths;

/**
 * CSV-file-backed implementation of EmployeeRepository.
 */
public class CsvEmployeeRepository implements EmployeeRepository {

    private final String filePath = AppPaths.dataFile("employee_info.csv").getPath();
    private final String loginFilePath = AppPaths.dataFile("employee_logins.csv").getPath();

    @Override
    public int nextEmployeeNumber() {
        List<Employee> employees = findAll();
        if (employees.isEmpty()) {
            return 10001;
        }
        return employees.stream()
                .mapToInt(Employee::getEmployeeNumber)
                .max()
                .orElse(10000) + 1;
    }

    /**
     * Tolerant of read failures (returns an empty list) since it's used
     * for read-only display; mutating operations use
     * {@link #findAllForMutation()} instead so a transient read failure
     * can't lead to silently overwriting the file with an empty list.
     */
    @Override
    public List<Employee> findAll() {
        try {
            return readEmployees();
        } catch (IOException | CsvException e) {
            System.err.println("Error loading employees: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @Override
    public Optional<Employee> findById(int employeeNumber) {
        return findAll().stream()
                .filter(e -> e.getEmployeeNumber() == employeeNumber)
                .findFirst();
    }

    @Override
    public void add(Employee employee) {
        List<Employee> employees = findAllForMutation();
        employees.add(employee);
        saveAll(employees);
    }

    @Override
    public void update(Employee updatedEmployee) {
        List<Employee> employees = findAllForMutation();
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getEmployeeNumber() == updatedEmployee.getEmployeeNumber()) {
                employees.set(i, updatedEmployee);
                break;
            }
        }
        saveAll(employees);
    }

    @Override
    public void delete(int empNum) {
        List<Employee> employees = findAllForMutation();
        employees.removeIf(emp -> emp.getEmployeeNumber() == empNum);
        saveAll(employees);
        deleteEmployeeLogin(empNum);
    }

    /**
     * UI HELPER: Safely parses numeric input from text fields.
     * Prevents crashes if user leaves field empty or includes currency symbols.
     */
    public static double parseDoubleSafe(String value, double currentValue) {
        if (value == null || value.trim().isEmpty()) return currentValue;
        try {
            String cleanValue = value.trim().replaceAll("[₱,]", "");
            return Double.parseDouble(cleanValue);
        } catch (NumberFormatException e) {
            return currentValue;
        }
    }

    // --- Private Helpers ---

    private List<Employee> findAllForMutation() {
        try {
            return readEmployees();
        } catch (IOException | CsvException e) {
            throw new UncheckedIOException(
                "Refusing to save changes: could not read existing employee data from " + filePath,
                e instanceof IOException ? (IOException) e : new IOException(e));
        }
    }

    private List<Employee> readEmployees() throws IOException, CsvException {
        List<Employee> employees = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(filePath))) {
            List<String[]> records = reader.readAll();
            boolean skipHeader = true;

            for (String[] rowData : records) {
                if (skipHeader) { skipHeader = false; continue; }
                if (rowData.length < 20) continue;

                try {
                    employees.add(new Employee(
                        Integer.parseInt(rowData[0].trim()),
                        rowData[1].trim(), rowData[2].trim(), rowData[3].trim(),
                        rowData[4].trim(), rowData[5].trim(), rowData[6].trim(),
                        rowData[7].trim(), rowData[8].trim(), rowData[9].trim(),
                        rowData[10].trim(), rowData[11].trim(),
                        parseDouble(rowData[12]), parseDouble(rowData[13]),
                        parseDouble(rowData[14]), parseDouble(rowData[15]),
                        parseDouble(rowData[16]), parseDouble(rowData[17]),
                        parseDouble(rowData[18]), rowData[19].trim()
                    ));
                } catch (NumberFormatException e) {
                    // Skip malformed rows
                }
            }
        }
        return employees;
    }

    private void saveAll(List<Employee> employees) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath))) {
            writer.writeNext(new String[]{
                "Employee #", "Last Name", "First Name", "Phone Number", "Status",
                "Position", "Supervisor", "Address", "SSS #", "PhilHealth #",
                "TIN #", "Pag-ibig #", "Basic Salary", "Rice Subsidy",
                "Phone Allowance", "Clothing Allowance", "Gross Semi-monthly Rate",
                "Hourly Rate", "Withholding Tax", "Birthday"
            });
            for (Employee emp : employees) {
                writer.writeNext(formatEmployeeData(emp));
            }
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to save employee records to " + filePath, e);
        }
    }

    /**
     * Deletes login credentials associated with an employee number.
     * Aborts without touching the file if the existing rows can't be
     * read, instead of overwriting it with a partial/empty list.
     */
    private void deleteEmployeeLogin(int empNum) {
        List<String[]> rows = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(loginFilePath))) {
            String[] header = reader.readNext();
            if (header != null) rows.add(header);

            String[] row;
            while ((row = reader.readNext()) != null) {
                if (row.length > 0 && !row[0].trim().equals(String.valueOf(empNum))) {
                    rows.add(row);
                }
            }
        } catch (IOException | CsvException e) {
            throw new UncheckedIOException(
                "Refusing to update login records: could not read " + loginFilePath,
                e instanceof IOException ? (IOException) e : new IOException(e));
        }

        try (CSVWriter writer = new CSVWriter(new FileWriter(loginFilePath))) {
            writer.writeAll(rows);
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to write " + loginFilePath, e);
        }
    }

    private static String[] formatEmployeeData(Employee employee) {
        return new String[]{
            String.valueOf(employee.getEmployeeNumber()), employee.getLastName(), employee.getFirstName(),
            employee.getPhoneNumber(), employee.getStatus(), employee.getPosition(), employee.getSupervisor(),
            employee.getAddress(), employee.getSssNumber(), employee.getPhilHealthNumber(), employee.getTinNumber(),
            employee.getPagIbigNumber(), String.valueOf(employee.getBasicSalary()), String.valueOf(employee.getRiceSubsidy()),
            String.valueOf(employee.getPhoneAllowance()), String.valueOf(employee.getClothingAllowance()),
            String.valueOf(employee.getGrossSemiMonthlyRate()), String.valueOf(employee.getHourlyRate()),
            String.valueOf(employee.getWithholdingTax()), employee.getBirthday()
        };
    }

    private static double parseDouble(String value) {
        try {
            return (value == null || value.trim().isEmpty() || value.equalsIgnoreCase("N/A")) ? 0.0 : Double.parseDouble(value.trim());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }
}
