package dao;

import model.Employee;
import java.util.List;
import java.util.Optional;

/**
 * Storage abstraction for Employee records. Callers depend on this
 * interface, not on how/where the data actually lives, so the CSV-backed
 * implementation (CsvEmployeeRepository) can later be swapped for a
 * database-backed one without changing any calling code.
 */
public interface EmployeeRepository {

    List<Employee> findAll();

    Optional<Employee> findById(int employeeNumber);

    int nextEmployeeNumber();

    void add(Employee employee);

    void update(Employee employee);

    void delete(int employeeNumber);
}
