package dao;

import com.opencsv.exceptions.CsvValidationException;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import model.AttendanceRecord;
import model.User;

/**
 * Storage abstraction for attendance records. Callers depend on this
 * interface, not on how/where records are stored, so the CSV-backed
 * implementation (CsvAttendanceRepository) can later be swapped for a
 * database-backed one without changing any calling code.
 */
public interface AttendanceRepository {

    List<AttendanceRecord> readAll() throws IOException, CsvValidationException;

    boolean updateRecords(List<AttendanceRecord> updatedRecords) throws IOException, CsvValidationException;

    List<String[]> getRecordsForEmployee(String empNo, LocalDate startDate, LocalDate endDate);

    void logTimeIn(User user) throws IOException;

    void logTimeOut(User user) throws IOException, CsvValidationException;
}
