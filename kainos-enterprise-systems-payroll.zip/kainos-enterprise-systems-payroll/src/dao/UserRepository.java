package dao;

import model.User;

/**
 * Storage abstraction for login credentials and authentication. Callers
 * depend on this interface, not on how/where credentials are stored, so
 * the CSV-backed implementation (CsvUserRepository) can later be swapped
 * for a database-backed one without changing any calling code.
 */
public interface UserRepository {

    User authenticate(String username, String password);

    String getSecurityQuestion(String employeeId);

    boolean verifySecurityAnswer(String employeeId, String inputAnswer);

    boolean updatePassword(String employeeId, String newPassword);
}
