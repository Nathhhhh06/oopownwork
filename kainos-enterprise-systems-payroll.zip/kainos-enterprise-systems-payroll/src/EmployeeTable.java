import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;
import java.util.Vector;
import java.util.Arrays;
import dao.EmployeeRepository;
import dao.CsvEmployeeRepository;
import model.Employee;
import model.User;
import ui.Theme;



public class EmployeeTable extends ui.AppFrame {
    private String selectedEmpNum;

    private final EmployeeRepository employeeRepository = new CsvEmployeeRepository();

    private AddEmployee addemp = new AddEmployee();
    private ViewEmpInfo viewinfo = new ViewEmpInfo();

    private static EmployeeTable instance;


    /**
     * standard constructor - HR, ADMIN, etc.
     */
    public EmployeeTable() {
        instance = this;
        initComponents();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                instance = null;
            }
        });

        configureTableModel();
        loadEmployeeData();
        adjustTableSettings();
    }

    /**
     * for the SUPPORT role - only loads supervised employees
     */
    public EmployeeTable(String supervisorId, String labelText) {
    instance = this;
    initComponents();
    jLabelEmpInfo.setText(labelText);   
    applyRoleRestrictions();           
    
    //  Set jButtonView label based on view mode
    if ("Employee Attendance".equalsIgnoreCase(labelText)) {
        jButtonView.setText("View Attendance");
        jButtonView.setVisible(true);
    } else if ("Employee Payslip".equalsIgnoreCase(labelText)) {
        jButtonView.setText("View Payslip");
        jButtonView.setVisible(true);
    }

    //  Ensure window closes cleanly
    setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosing(java.awt.event.WindowEvent e) {
            instance = null;
        }
    });

    configureTableModel();  // ?Initialize table columns

    // ️ Load employee data based on label + role
    String role = User.getLoggedInUser().getRole().trim();

    if ("Employee Payslip".equalsIgnoreCase(labelText)) {
        loadEmployeeData(); // All employees shown in Payslip mode

    } else if ("Employee Attendance".equalsIgnoreCase(labelText)) {
        if ("ADMIN".equalsIgnoreCase(role)) {
            loadEmployeeData(); // ADMIN sees full list for Attendance
        } else {
            loadSupervisedEmployees(supervisorId); // SUPPORT sees filtered list
        }

    } else {
        loadSupervisedEmployees(supervisorId); // Fallback for any other label
    }

    adjustTableSettings(); // Final formatting and column alignment
}




   
    private void applyRoleRestrictions() {
    String role = User.getLoggedInUser().getRole();
    String viewLabel = jLabelEmpInfo.getText().trim();

    // Restrict SUPPORT always, and ADMIN only in Payslip & Attendance modes
    if ("SUPPORT".equalsIgnoreCase(role) || 
        ("ADMIN".equalsIgnoreCase(role) && 
         ("Employee Payslip".equalsIgnoreCase(viewLabel) ||
          "Employee Attendance".equalsIgnoreCase(viewLabel)))) {

        Dimension originalSize = new Dimension(120, 35);

        if (jButtonAdd != null) {
            jButtonAdd.setText("");
            jButtonAdd.setEnabled(false);
            jButtonAdd.setPreferredSize(originalSize);
            jButtonAdd.setMinimumSize(originalSize);
            jButtonAdd.setMaximumSize(originalSize);
            jButtonAdd.setContentAreaFilled(false);
            jButtonAdd.setBorderPainted(false);
        }

        if (jButtonUpdate != null) {
            jButtonUpdate.setText("");
            jButtonUpdate.setEnabled(false);
            jButtonUpdate.setPreferredSize(originalSize);
            jButtonUpdate.setMinimumSize(originalSize);
            jButtonUpdate.setMaximumSize(originalSize);
            jButtonUpdate.setContentAreaFilled(false);
            jButtonUpdate.setBorderPainted(false);
        }

        if (jButtonDelete != null) {
            jButtonDelete.setText("");
            jButtonDelete.setEnabled(false);
            jButtonDelete.setPreferredSize(originalSize);
            jButtonDelete.setMinimumSize(originalSize);
            jButtonDelete.setMaximumSize(originalSize);
            jButtonDelete.setContentAreaFilled(false);
            jButtonDelete.setBorderPainted(false);
        }
    }
}





    /**
     * Get current table instance.
     */
    public static EmployeeTable getInstance() {
        return instance;
    }

    
    public String getSelectedEmpNum() { 
        return selectedEmpNum; 
    }
    /**
     * Table column config.
     */
    private void configureTableModel() {
        DefaultTableModel model = new DefaultTableModel(
            new Vector<>(Arrays.asList(
                "Employee Number", "Last Name", "First Name", "Phone Number", "Status", "Position", "Immediate Supervisor"
            )),
            0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTableEmpTable.setModel(model);
    }

    /**
     * loads the full employee list (HR / ADMIN)
     */
    public void loadEmployeeData() {
        DefaultTableModel model = (DefaultTableModel) jTableEmpTable.getModel();
        model.setRowCount(0);

        List<Employee> employees = employeeRepository.findAll();

        if (employees == null || employees.isEmpty()) {
            System.out.println("No employees found! Check CSV formatting or reload process.");
            JOptionPane.showMessageDialog(this, "Error: Employee data failed to load!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            for (Employee emp : employees) {
                model.addRow(new Object[]{ 
                    emp.getEmployeeNumber(), emp.getLastName(), emp.getFirstName(), 
                    emp.getPhoneNumber(), emp.getStatus(), emp.getPosition(), emp.getSupervisor()
                });
            }
        }
    }

    /**
     *  Loads only employees supervised by the specified user
     */
    private void loadSupervisedEmployees(String supervisorId) {
    DefaultTableModel model = (DefaultTableModel) jTableEmpTable.getModel();
    model.setRowCount(0);

    List<Employee> employees = employeeRepository.findAll();

    if (employees == null || employees.isEmpty()) {
        System.out.println("No employees found! Check CSV formatting or reload process.");
        JOptionPane.showMessageDialog(this, "Error: Employee data failed to load!", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        // Build full supervisor name in "LastName  FirstName" format
        String currentSupervisorName = User.getLoggedInUser().getLastName().trim() + "  " + User.getLoggedInUser().getFirstName().trim();

        for (Employee emp : employees) {
            String listedSupervisor = emp.getSupervisor() != null ? emp.getSupervisor().trim() : "";
            String employeeFullName = emp.getLastName().trim() + "  " + emp.getFirstName().trim();

            if (listedSupervisor.equalsIgnoreCase(currentSupervisorName) ||
                employeeFullName.equalsIgnoreCase(currentSupervisorName)) {

                model.addRow(new Object[]{ 
                    emp.getEmployeeNumber(),
                    emp.getLastName(),
                    emp.getFirstName(),
                    emp.getPhoneNumber(),
                    emp.getStatus(),
                    emp.getPosition(),
                    emp.getSupervisor()
                });
            }
        }
    }
}

    

    private String formatIDLive(String input) {
        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            formatted.append(input.charAt(i));
            if ((i + 1) % 3 == 0 && i + 1 < input.length()) {
                formatted.append("-");
            }
        }
        return formatted.toString();
    }

    /**
     * Reloads full employee table
     */
    public void refreshEmployeeTable() {
        if (instance != null) {
            DefaultTableModel model = (DefaultTableModel) jTableEmpTable.getModel();
            model.setRowCount(0);

            List<Employee> employees = employeeRepository.findAll();

            if (employees.isEmpty()) {
                System.err.println("WARNING: Employee list is empty after refresh!");
            } else {
                System.out.println("Employee list successfully refreshed. Total employees: " + employees.size());
            }

            for (Employee emp : employees) {
                model.addRow(new Object[]{ 
                    emp.getEmployeeNumber(), emp.getLastName(), emp.getFirstName(), 
                    emp.getPhoneNumber(), emp.getStatus(), emp.getPosition(), emp.getSupervisor()
                });
            }
        }
    }

    /**
     * Align and resize final column
     */
        private void adjustTableSettings() {
        jTableEmpTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        jTableEmpTable.getColumnModel().getColumn(6).setPreferredWidth(300);

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(DefaultTableCellRenderer.LEFT);
        jTableEmpTable.getColumnModel().getColumn(6).setCellRenderer(renderer);
    }




    // build the employee table window
    private void initComponents() {
        setTitle("Employee Records");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonAdd = new JButton("Add New Employee");
        jButtonExit = new JButton("Close");
        jButtonView = new JButton("View");
        jButtonUpdate = new JButton("Update");
        jButtonDelete = new JButton("Delete");
        jTableEmpTable = new JTable();
        jTableEmpTable.setModel(new DefaultTableModel(new Object[0][7], new String[]{
            "Employee Number", "Last Name", "First Name", "Phone Number",
            "Status", "Position", "Immediate Supervisor"
        }));
        jScrollPane1 = new JScrollPane(jTableEmpTable);
        jLabelEmpInfo = new JLabel("Employee Information");
        jLabel1 = new JLabel(Theme.CREDITS);

        jButtonAdd.addActionListener(this::jButtonAddActionPerformed);
        jButtonExit.addActionListener(this::jButtonExitActionPerformed);
        jButtonView.addActionListener(this::jButtonViewActionPerformed);
        jButtonUpdate.addActionListener(this::jButtonUpdateActionPerformed);
        jButtonDelete.addActionListener(this::jButtonDeleteActionPerformed);

        jLabelEmpInfo.setForeground(Color.WHITE);
        jLabelEmpInfo.setFont(jLabelEmpInfo.getFont().deriveFont(java.awt.Font.BOLD, 26f));
        jLabel1.setForeground(new Color(0xC7D2E8));
        jLabel1.setFont(jLabel1.getFont().deriveFont(11f));

        jButtonAdd.setBackground(Theme.ACCENT);
        jButtonAdd.setForeground(Color.WHITE);
        jButtonExit.putClientProperty("JButton.buttonType", "borderless");
        jButtonExit.setForeground(Color.WHITE);

        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setBackground(Theme.NAVY);
        content.setBorder(BorderFactory.createEmptyBorder(20, 24, 16, 24));

        content.add(jLabelEmpInfo, BorderLayout.NORTH);

        JPanel middle = new JPanel(new BorderLayout(16, 0));
        middle.setOpaque(false);
        middle.add(jScrollPane1, BorderLayout.CENTER);

        JPanel sideButtons = new JPanel();
        sideButtons.setOpaque(false);
        sideButtons.setLayout(new BoxLayout(sideButtons, BoxLayout.Y_AXIS));
        for (JButton b : new JButton[]{jButtonView, jButtonUpdate, jButtonDelete}) {
            b.setAlignmentX(Component.CENTER_ALIGNMENT);
            b.setMaximumSize(new Dimension(140, 34));
            b.setPreferredSize(new Dimension(140, 34));
            sideButtons.add(b);
            sideButtons.add(Box.createVerticalStrut(10));
        }
        sideButtons.remove(sideButtons.getComponentCount() - 1);
        JPanel sideWrap = new JPanel(new BorderLayout());
        sideWrap.setOpaque(false);
        sideWrap.add(sideButtons, BorderLayout.NORTH);
        middle.add(sideWrap, BorderLayout.EAST);

        content.add(middle, BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout());
        south.setOpaque(false);
        JPanel bar = new JPanel(new BorderLayout());
        bar.setOpaque(false);
        bar.add(jButtonAdd, BorderLayout.WEST);
        bar.add(jButtonExit, BorderLayout.EAST);
        south.add(bar, BorderLayout.NORTH);
        south.add(jLabel1, BorderLayout.SOUTH);
        content.add(south, BorderLayout.SOUTH);

        jScrollPane1.setPreferredSize(new Dimension(880, 420));
        setContentPane(content);
        setMinimumSize(new Dimension(820, 560));
        pack();
    }

    private void jButtonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExitActionPerformed
        // TODO add your handling code here:
        dispose ();
    }//GEN-LAST:event_jButtonExitActionPerformed

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        // TODO add your handling code here:
        addemp.show();
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonViewActionPerformed
                        
    int selectedRow = jTableEmpTable.getSelectedRow(); // Get selected row index

    if (selectedRow != -1) {
        String empNumber = jTableEmpTable.getValueAt(selectedRow, 0).toString().trim();
        
        // Store the selected employee number in the class field
        selectedEmpNum = empNumber;

        String viewMode = jLabelEmpInfo.getText().trim();

        try {
            if ("Employee Attendance".equalsIgnoreCase(viewMode)) {
                // SUPPORT view → open Attendance screen
                Attendance attendanceWindow = new Attendance(empNumber);
                attendanceWindow.setVisible(true);
                attendanceWindow.setLocationRelativeTo(null);

            } else if ("Employee Payslip".equalsIgnoreCase(viewMode)) {
                // ADMIN/SUPPORT → open Payslip screen
                Payslip payslipWindow = new Payslip(empNumber);
                payslipWindow.setVisible(true);
                payslipWindow.setLocationRelativeTo(null);

            } else {
                // Default view → open EditEmpInfo in read-only mode
                int empNumInt = Integer.parseInt(empNumber); // Validate number format
                EditEmpInfo editEmpInfoWindow = new EditEmpInfo(empNumInt, true); 
                editEmpInfoWindow.setVisible(true);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error: Invalid Employee Number format!", "Data Error", JOptionPane.ERROR_MESSAGE);
            System.err.println("ERROR: Failed to parse Employee Number - " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select an employee to view!", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jButtonViewActionPerformed

    private void jButtonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUpdateActionPerformed
    int selectedRow = jTableEmpTable.getSelectedRow(); // Get the selected row index

    if (selectedRow == -1) { // Ensure a row is selected before proceeding
        JOptionPane.showMessageDialog(this, "Please select an employee to update!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Retrieve Employee Number safely
    String empNumStr = jTableEmpTable.getValueAt(selectedRow, 0).toString().trim();

    // Store the selected employee number in the class field
    selectedEmpNum = empNumStr;

    try {
        int empNum = Integer.parseInt(empNumStr);

        // Open the Edit Employee window in Editable Mode
        SwingUtilities.invokeLater(() -> {
            EditEmpInfo editWindow = new EditEmpInfo(empNum, false);  
            editWindow.setVisible(true);
        });

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Error: Invalid Employee Number format!", "Data Error", JOptionPane.ERROR_MESSAGE);
        System.err.println("ERROR: Failed to parse Employee Number - " + e.getMessage());
    }
    }//GEN-LAST:event_jButtonUpdateActionPerformed

    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteActionPerformed
    // Handles the deletion of an employee when the "Delete" button is clicked

    int selectedRow = jTableEmpTable.getSelectedRow(); // Get the selected row index

    if (selectedRow == -1) { // Ensure a row is selected before proceeding
        JOptionPane.showMessageDialog(this, "Please select an employee to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        return; // Stop execution if no row is selected
    }

    // Ask for confirmation before deleting the employee
    int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this employee?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) {
        return; // Cancel deletion if the user selects "No"
    }

    // Retrieve Employee Number of the selected row
    int empNumToDelete = Integer.parseInt(jTableEmpTable.getValueAt(selectedRow, 0).toString());

    // Store the selected employee number in the class field
    selectedEmpNum = String.valueOf(empNumToDelete);

    try {
        // Call EmployeeRepository to remove employee from CSV
        employeeRepository.delete(empNumToDelete);

        // Remove employee from JTable visually
        DefaultTableModel model = (DefaultTableModel) jTableEmpTable.getModel();
        model.removeRow(selectedRow); // Delete row from table view

        // Notify the user that deletion was successful
        JOptionPane.showMessageDialog(this, "Employee deleted successfully!");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error deleting employee: " + e.getMessage(), "System Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeTable().setVisible(true);
            }
        });
    }

    private JButton jButtonAdd;
    private JButton jButtonDelete;
    private JButton jButtonExit;
    private JButton jButtonUpdate;
    private JButton jButtonView;
    private JLabel jLabel1;
    private JLabel jLabelEmpInfo;
    private JScrollPane jScrollPane1;
    private JTable jTableEmpTable;
}
