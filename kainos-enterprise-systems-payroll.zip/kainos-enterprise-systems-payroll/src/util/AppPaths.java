package util;

import java.io.File;
import java.net.URISyntaxException;

/**
 * Resolves the on-disk location of the CSV data files under src/data.
 * A plain "src/data/..." literal only works when the JVM's working
 * directory happens to be the project root (true inside NetBeans, not
 * true when launching the built jar from dist/ or elsewhere), so this
 * walks up from wherever the running code actually lives to find it.
 */
public final class AppPaths {

    private static volatile File projectRoot;

    private AppPaths() {}

    public static File dataFile(String fileName) {
        return new File(findProjectRoot(), "src/data/" + fileName);
    }

    private static File findProjectRoot() {
        File cached = projectRoot;
        if (cached != null) {
            return cached;
        }

        File cwd = new File(System.getProperty("user.dir"));
        if (new File(cwd, "src/data").isDirectory()) {
            return projectRoot = cwd;
        }

        for (File dir = codeSourceLocation(); dir != null; dir = dir.getParentFile()) {
            if (new File(dir, "src/data").isDirectory()) {
                return projectRoot = dir;
            }
        }

        // Nothing found; fall back to cwd so the caller gets a normal
        // "file not found" error instead of an NPE.
        return projectRoot = cwd;
    }

    private static File codeSourceLocation() {
        try {
            File location = new File(AppPaths.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI());
            return location.isFile() ? location.getParentFile() : location;
        } catch (URISyntaxException | NullPointerException e) {
            return null;
        }
    }
}
