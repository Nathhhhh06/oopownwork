import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import ui.Theme;

// Old employee-info screen. Not really used anymore - the "View" button opens
// EditEmpInfo in read-only mode instead. Left here as a simple placeholder.
public class ViewEmpInfo extends ui.AppFrame {

    public ViewEmpInfo() {
        initComponents();
    }

    // build the screen
    private void initComponents() {
        setTitle("Employee Info");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jButton1 = new JButton("Close");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jButton1.putClientProperty("JButton.buttonType", "borderless");

        JLabel heading = new JLabel("Employee Information");
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 20f));
        heading.setForeground(Color.WHITE);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.NAVY);
        header.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        header.add(heading, BorderLayout.WEST);

        JLabel note = new JLabel("This view is not currently used - open an employee from the table instead.");
        note.setForeground(Theme.TEXT_MUTED);

        JPanel body = new JPanel(new BorderLayout());
        body.setBackground(Color.WHITE);
        body.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        body.add(note, BorderLayout.NORTH);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(BorderFactory.createEmptyBorder(8, 24, 12, 24));
        JLabel credits = new JLabel(Theme.CREDITS);
        credits.setForeground(Theme.TEXT_MUTED);
        credits.setFont(credits.getFont().deriveFont(11f));
        footer.add(credits, BorderLayout.WEST);
        footer.add(jButton1, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(Color.WHITE);
        content.add(header, BorderLayout.NORTH);
        content.add(body, BorderLayout.CENTER);
        content.add(footer, BorderLayout.SOUTH);

        setContentPane(content);
        setMinimumSize(new Dimension(560, 360));
        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        dispose ();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewEmpInfo().setVisible(true);
            }
        });
    }

    private JButton jButton1;
}