/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author singh
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import dao.UserRepository;
import dao.CsvUserRepository;
import model.User;
import ui.Theme;
import util.FontUtil;

public class LoginScreen1 extends ui.AppFrame {

    private final UserRepository userRepository = new CsvUserRepository();

    private int failedAttempts = 0;
    private long blockUntilTime = 0;

    private JTextField jTextFieldUsername;
    private JPasswordField jPasswordField;
    private JButton jButtonLogin;
    private JButton jButtonReset;

    public LoginScreen1() {
        initComponents();
    }

    // build the login window
    private void initComponents() {
        setTitle("MotorPH Payroll - Sign in");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.add(buildBrandingPanel(), BorderLayout.WEST);
        root.add(buildFormPanel(), BorderLayout.CENTER);
        setContentPane(root);

        setMinimumSize(new Dimension(760, 500));
        pack();
    }

    // left navy panel - logo + "MotorPH" wordmark
    private JPanel buildBrandingPanel() {
        JPanel brand = new JPanel(new GridBagLayout());
        brand.setBackground(Theme.NAVY);
        brand.setPreferredSize(new Dimension(340, 520));
        brand.setBorder(BorderFactory.createEmptyBorder(0, 24, 0, 24));

        JPanel stack = new JPanel();
        stack.setOpaque(false);
        stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS));

        URL logoUrl = getClass().getResource("/loginLogo.png");
        if (logoUrl != null) {
            JLabel logo = new JLabel(new ImageIcon(logoUrl));
            logo.setAlignmentX(Component.CENTER_ALIGNMENT);
            stack.add(logo);
            stack.add(Box.createVerticalStrut(24));
        }

        JLabel wordmark = new JLabel("MotorPH");
        wordmark.setForeground(Color.WHITE);
        wordmark.setFont(FontUtil.getKinetikaFont(40f));
        wordmark.setAlignmentX(Component.CENTER_ALIGNMENT);
        stack.add(wordmark);

        JLabel tagline = new JLabel("Payroll System");
        tagline.setForeground(new Color(0xC7D2E8));
        tagline.setFont(tagline.getFont().deriveFont(15f));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);
        stack.add(Box.createVerticalStrut(6));
        stack.add(tagline);

        brand.add(stack);
        return brand;
    }

    // right white panel - username / password fields
    private JPanel buildFormPanel() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(Color.WHITE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        form.setBorder(BorderFactory.createEmptyBorder(32, 40, 32, 40));

        JLabel heading = new JLabel("Employee Login");
        heading.setFont(heading.getFont().deriveFont(Font.BOLD, 24f));

        JLabel subheading = new JLabel("Sign in to continue");
        subheading.setForeground(Theme.TEXT_MUTED);

        jTextFieldUsername = new JTextField(18);
        jTextFieldUsername.putClientProperty("JTextField.placeholderText", "Username");

        jPasswordField = new JPasswordField(18);
        jPasswordField.putClientProperty("JTextField.placeholderText", "Password");
        jPasswordField.addActionListener(this::jButtonLoginActionPerformed);

        jButtonLogin = new JButton("Log in");
        jButtonLogin.setBackground(Theme.NAVY);
        jButtonLogin.setForeground(Color.WHITE);
        jButtonLogin.putClientProperty("JButton.buttonType", "default");
        jButtonLogin.addActionListener(this::jButtonLoginActionPerformed);

        jButtonReset = new JButton("Forgot password?");
        jButtonReset.putClientProperty("JButton.buttonType", "borderless");
        jButtonReset.setForeground(Theme.ACCENT);
        jButtonReset.setHorizontalAlignment(SwingConstants.LEFT);
        jButtonReset.setMargin(new Insets(0, 0, 0, 0));
        jButtonReset.addActionListener(this::jButtonResetActionPerformed);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.insets = new Insets(0, 0, 4, 0);

        c.gridy = 0;
        form.add(heading, c);
        c.gridy = 1;
        c.insets = new Insets(0, 0, 20, 0);
        form.add(subheading, c);

        c.gridy = 2;
        c.insets = new Insets(0, 0, 4, 0);
        form.add(new JLabel("Username"), c);
        c.gridy = 3;
        c.insets = new Insets(0, 0, 14, 0);
        form.add(jTextFieldUsername, c);

        c.gridy = 4;
        c.insets = new Insets(0, 0, 4, 0);
        form.add(new JLabel("Password"), c);
        c.gridy = 5;
        c.insets = new Insets(0, 0, 20, 0);
        form.add(jPasswordField, c);

        c.gridy = 6;
        c.ipady = 6;
        c.insets = new Insets(0, 0, 8, 0);
        form.add(jButtonLogin, c);

        c.gridy = 7;
        c.ipady = 0;
        c.insets = new Insets(0, 0, 0, 0);
        form.add(jButtonReset, c);

        outer.add(form);
        return outer;
    }

    private void jButtonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLoginActionPerformed
        long currentTime = System.currentTimeMillis();

        //  Check if user is currently blocked
        if (currentTime < blockUntilTime) {
            long secondsRemaining = (blockUntilTime - currentTime) / 1000;
            JOptionPane.showMessageDialog(this,
                "Too many incorrect attempts.\nYour account is temporarily blocked for " + secondsRemaining + " seconds.\n" +
                "Please wait or reset your password.",
                "Login Blocked",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        String username = jTextFieldUsername.getText().trim();
        String password = jPasswordField.getText().trim();

        // 1. Authenticate username and password using the updated UserRepository
        // This will now return a User object with email and employeeId
        User user = userRepository.authenticate(username, password);

        if (user != null) {
            // Password is correct. Now, conceptually check 2FA base on the given dummy emails in the CSV
            boolean is2FAEnabledForThisUser = true;

            if (is2FAEnabledForThisUser) {
                // --- START DEMO 2FA PLACEHOLDER LOGIC ---

                // 1. Show the "Code Sent" message using the user's email from the User object
                String userEmail = user.getEmail(); // Get the dummy email from the User object
                JOptionPane.showMessageDialog(this,
                    "A 6-digit verification code has been conceptually sent to your registered email: " + maskEmail(userEmail) + ".\n" +
                    "For this presentation, you can enter any random 6-digit number.",
                    "Two-Factor Authentication Required (DEMO)",
                    JOptionPane.INFORMATION_MESSAGE);
                

                // 2. Prompt for OTP input
                String enteredOTP = JOptionPane.showInputDialog(this, "Enter the 6-digit code (any number for demo):");
                

                // 3. DEMO OTP Verification: Accept ANY non-empty input
                if (enteredOTP != null && !enteredOTP.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "OTP accepted (DEMO). Login successful!");
                    // Proceed with actual login actions
                    proceedWithSuccessfulLogin(user); // Call the helper method
                } else {
                    // User canceled the OTP input dialog or entered nothing
                    JOptionPane.showMessageDialog(this, "OTP not entered. Login failed.", "2FA Demo Canceled", JOptionPane.ERROR_MESSAGE);
                    
                }

                // --- END DEMO 2FA PLACEHOLDER LOGIC ---

            } else {
                // No 2FA conceptually enabled for this user, proceed with regular successful login
                proceedWithSuccessfulLogin(user);
            }
        } else {
            //  Incorrect login (existing code for password failure)
            failedAttempts++;

            if (failedAttempts >= 3) {
                blockUntilTime = System.currentTimeMillis() + (5 * 60 * 1000); // 5-minute lockout (adjust time as needed)
                JOptionPane.showMessageDialog(this,
                    "Invalid login 3 times.\nAccount is locked for 5 minutes.\n" +
                    "Consider resetting your password.",
                    "Account Temporarily Blocked",
                    JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Invalid username or password.\nAttempt " + failedAttempts + " of 3.",
                    "Login Failed",
                    JOptionPane.WARNING_MESSAGE);
            }

            // Clear fields on login failure for next attempt
            jTextFieldUsername.setText("");
            jPasswordField.setText("");
        }
    }//GEN-LAST:event_jButtonLoginActionPerformed

    private void jButtonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonResetActionPerformed
        // Your existing reset password logic remains unchanged
        String empId = JOptionPane.showInputDialog(this, "Enter your Employee ID:");
        if (empId == null || empId.trim().isEmpty()) return;

        // Use UserRepository to get security question
        String question = userRepository.getSecurityQuestion(empId.trim());
        if (question == null) {
            JOptionPane.showMessageDialog(this, "Employee ID not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String answer = JOptionPane.showInputDialog(this, question);
        if (answer == null || answer.trim().isEmpty()) return;

        // Use UserRepository to verify security answer
        boolean isCorrect = userRepository.verifySecurityAnswer(empId.trim(), answer.trim());
        if (!isCorrect) {
            JOptionPane.showMessageDialog(this, "Incorrect answer. Please try again.", "Security Check Failed", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String newPassword = null;
        boolean validPassword = false;

        //  Repeat until user enters a valid password or cancels
        while (!validPassword) {
            JPasswordField passwordField = new JPasswordField();
            passwordField.setEchoChar('*'); // Hide characters being typed

            int confirm = JOptionPane.showConfirmDialog(this, passwordField, "Enter your new password:", JOptionPane.OK_CANCEL_OPTION);

            if (confirm != JOptionPane.OK_OPTION) {
                JOptionPane.showMessageDialog(this, "Password reset canceled.");
                return;
            }

            newPassword = new String(passwordField.getPassword()).trim();

            // Password validation rules
            boolean isAlphanumeric = newPassword.matches("^[a-zA-Z0-9]+$"); // Only letters and numbers
            boolean hasCapital = newPassword.matches(".*[A-Z].*"); // At least one uppercase letter
            boolean hasNumber = newPassword.matches(".*\\d.*"); // At least one digit

            if (newPassword.isEmpty() || !isAlphanumeric || !hasCapital || !hasNumber) {
                JOptionPane.showMessageDialog(this,
                    "Password must meet the following requirements:\n" +
                    "- Only letters and numbers (no symbols)\n" +
                    "- At least one uppercase letter\n" +
                    "- At least one number",
                    "Invalid Password Format",
                    JOptionPane.ERROR_MESSAGE);
            } else {
                validPassword = true;
            }
        }

        // Use UserRepository to update password
        boolean updated = userRepository.updatePassword(empId.trim(), newPassword);
        if (updated) {
            JOptionPane.showMessageDialog(this, "Password reset successfully.");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update password.", "Update Failed", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButtonResetActionPerformed

    // --- NEW HELPER METHODS ---

    /**
     * Encapsulates the actions for a successful login, whether 2FA was used or not.
     * This method will open the MainMenu and dispose of the LoginScreen.
     * @param user The authenticated User object.
     */
    private void proceedWithSuccessfulLogin(User user) {
        User.setLoggedInUser(user); // Set the globally logged-in user
        failedAttempts = 0; // Reset failed attempts on successful login
        blockUntilTime = 0; // Clear any active lockout

        JOptionPane.showMessageDialog(this, "Welcome, " + user.getFirstName() + "!");
        

        // Open the MainMenu and center it
        MainMenu main = new MainMenu(user); // Assuming MainMenu constructor takes a User object
        main.setVisible(true);
        main.setLocationRelativeTo(null);

        // Optional role-based actions (from your original code)
        switch (user.getRole().toUpperCase()) {
            case "EMPLOYEE":
                // new Attendance(user.getEmployeeId()).setVisible(true); // Example comment
                break;
            case "HR":
                // optional: HR interface
                break;
            case "SUPPORT":
                // optional: Support interface
                break;
            case "ADMIN":
                // optional: Admin interface
                break;
        }

        this.dispose(); // Close the current login screen
    }

    /**
     * Utility method to mask an email address for display.
     * E.g., "john.doe@example.com" becomes "jo*****@example.com"
     * @param email The email address to mask.
     * @return The masked email string.
     */
    private String maskEmail(String email) {
        if (email == null || email.indexOf('@') <= 1) return email; // Handle null, empty, or very short emails
        int atIndex = email.indexOf('@');
        String prefix = email.substring(0, Math.min(atIndex, 2)); // Show first 2 characters before '@'
        String domain = email.substring(atIndex); // Keep the domain part as is
        return prefix + "*****" + domain;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel
        // so logout knows how to reopen the login screen
        ui.AppFrame.setLoginScreenFactory(LoginScreen1::new);

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginScreen1().setVisible(true);
            }
        });
    }

}