package model;

public class User {
    private String employeeId;
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String role;

    private String email;

    public User(String employeeId, String firstName, String lastName,
                String username, String password, String role, String email) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
    }

    // login state now lives in Session - these just forward so old code still works
    public static void setLoggedInUser(User u) {
        Session.start(u);
    }

    public static User getLoggedInUser() {
        return Session.current();
    }

    // Getters
    public String getEmployeeId() { return employeeId; }
    public String getFirstName()   { return firstName; }
    public String getLastName()    { return lastName; }
    public String getUsername()    { return username; }
    public String getPassword()    { return password; }
    public String getRole()        { return role; }
    public String getEmail()       { return email; }
    
}
