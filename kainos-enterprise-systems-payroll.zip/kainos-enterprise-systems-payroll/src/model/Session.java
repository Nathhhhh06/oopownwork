package model;

/*
 * Holds the user that is currently logged in. Replaces the old
 * User.loggedInUser static field - User.getLoggedInUser()/setLoggedInUser()
 * now just call through to here so the old code still works.
 */
public final class Session {

    private static User currentUser;

    private Session() {
    }

    public static void start(User user) {
        currentUser = user;
    }

    public static void end() {
        currentUser = null;
    }

    // the logged-in user, or null if nobody is logged in
    public static User current() {
        return currentUser;
    }

    public static boolean isActive() {
        return currentUser != null;
    }
}
