import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.awt.*;
import java.awt.Font;
import java.awt.image.BufferedImage;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JYearChooser;
import ui.Theme;
import java.io.FileOutputStream;
import javax.imageio.ImageIO;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import javax.swing.JFileChooser;
import java.util.List;
import dao.EmployeeRepository;
import dao.CsvEmployeeRepository;
import dao.AttendanceRepository;
import dao.CsvAttendanceRepository;
import model.Employee;
import model.AttendanceRecord;
import service.AttendanceCalculator;
import service.SalaryComputation;




/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author singh
 */

public class Payslip extends ui.AppFrame {
    private final EmployeeRepository employeeRepository = new CsvEmployeeRepository();
    private final AttendanceRepository attendanceRepository = new CsvAttendanceRepository();

    private String empNo;
    public Payslip(String empNo) {
        this.empNo = empNo;
        initComponents();
        loadEmployeePayslip(empNo);
    }

    //  This allows creating Payslip with no parameters
    public Payslip() {
        initComponents();
    }
    
    private String getMonthYearString(int month, int year) {
    String[] monthNames = {"January", "February", "March", "April", "May", "June",
                           "July", "August", "September", "October", "November", "December"};
    return monthNames[month - 1] + " " + year;  // ✅ Ensures output like "June 2025"
}


    private void loadEmployeePayslip(String empNo) {

    // Retrieve Employee Details from File/Database
    Employee e = employeeRepository.findById(Integer.parseInt(empNo)).orElse(null);

    if (e != null) {
        employeeNameLabel.setText(e.getFirstName() + " " + e.getLastName());
        employeeNumber.setText(empNo);
        position.setText(e.getPosition());
        employmentStatus.setText(e.getStatus());
        sssNumber.setText(e.getSssNumber());
        tinNumber.setText(e.getTinNumber());
        philhealthNumber.setText(e.getPhilHealthNumber());
        pagIbigNumber.setText(e.getPagIbigNumber());

        //  Set Allowance Fields
        double phone = e.getPhoneAllowance();
        double clothing = e.getClothingAllowance();
        double rice = e.getRiceSubsidy();

        phoneAllowance.setText(String.format("₱%,.2f", phone));
        clothingAllowance.setText(String.format("₱%,.2f", clothing));
        riceSubsidy.setText(String.format("₱%,.2f", rice));

        //  Set Hourly Rate (Restored)
        String cleanedRate = String.format("%.2f", e.getHourlyRate()).replaceAll("[^0-9.]", "");
        hourlyRate.setText(cleanedRate);

        //  Compute Total Benefits
        double totalBenefits = phone + clothing + rice;
        benefitsLabel.setText(String.format("₱%,.2f", totalBenefits));
    } else {
        JOptionPane.showMessageDialog(this, "Employee not found!", "Lookup Error", JOptionPane.ERROR_MESSAGE);
    }
}

    // build the payslip window
    private void initComponents() {
        setTitle("Electronic Payslip");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        // these labels get filled in when an employee is loaded
        hoursWorked = valueLabel("0");
        overtime = valueLabel("0");
        hourlyRate = valueLabel("0");
        phoneAllowance = valueLabel("0");
        clothingAllowance = valueLabel("0");
        riceSubsidy = valueLabel("0");
        sssPremiumLabel = valueLabel("0");
        philhealthContributionLabel = valueLabel("0");
        pagibigContributionLabel = valueLabel("0");
        witholdingTaxLabel = valueLabel("0");
        witholdingTaxLabel.setForeground(new Color(0xB00020));
        grossIncomeLabel = valueLabel("0");
        benefitsLabel = valueLabel("0");
        totalDeductionsLabel = valueLabel("0");
        otherAdjustments = valueLabel("0");
        netPayLabel = valueLabel("0");
        netPayLabel.setFont(netPayLabel.getFont().deriveFont(Font.BOLD, 16f));
        netPayLabel.setForeground(new Color(0x2E7D32));
        employeeNumber = valueLabel("");
        position = valueLabel("");
        employmentStatus = valueLabel("");
        sssNumber = valueLabel("");
        tinNumber = valueLabel("");
        philhealthNumber = valueLabel("");
        pagIbigNumber = valueLabel("");

        employeeNameLabel = new JLabel("");
        employeeNameLabel.setFont(employeeNameLabel.getFont().deriveFont(Font.BOLD, 18f));
        employeeNameLabel.setForeground(Theme.NAVY);
        payDateLabel = new JLabel("SELECT CUTOFF");

        monthSelect = new JMonthChooser();
        yearSelect = new JYearChooser();
        checkPayslipButton = new JButton("Check Payslip");
        downloadButton = new JButton("Download");
        exitButton = new JButton("Close");

        checkPayslipButton.addActionListener(this::checkPayslipButtonActionPerformed);
        downloadButton.addActionListener(this::downloadButtonActionPerformed);
        exitButton.addActionListener(this::exitButtonActionPerformed);
        for (JButton b : new JButton[]{checkPayslipButton, downloadButton}) {
            b.setBackground(Theme.NAVY);
            b.setForeground(Color.WHITE);
        }
        exitButton.putClientProperty("JButton.buttonType", "borderless");
        exitButton.setForeground(new Color(0xB00020));

        // header
        JPanel titleRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        titleRow.setOpaque(false);
        JLabel titleLead = new JLabel("ELECTRONIC PAYSLIP OF:");
        titleLead.setFont(titleLead.getFont().deriveFont(Font.BOLD, 18f));
        titleLead.setForeground(Theme.NAVY);
        titleRow.add(titleLead);
        titleRow.add(employeeNameLabel);

        JPanel cutoffRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        cutoffRow.setOpaque(false);
        cutoffRow.add(boldLabel("For Paydate:"));
        cutoffRow.add(payDateLabel);
        cutoffRow.add(Box.createHorizontalStrut(24));
        cutoffRow.add(boldLabel("Cutoff:"));
        cutoffRow.add(monthSelect);
        cutoffRow.add(yearSelect);
        cutoffRow.add(checkPayslipButton);

        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        titleRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        cutoffRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel downloadRow = new JPanel(new BorderLayout());
        downloadRow.setOpaque(false);
        downloadRow.add(header, BorderLayout.CENTER);
        header.add(titleRow);
        header.add(Box.createVerticalStrut(8));
        header.add(cutoffRow);
        JPanel dlWrap = new JPanel(new BorderLayout());
        dlWrap.setOpaque(false);
        dlWrap.add(downloadButton, BorderLayout.NORTH);
        downloadRow.add(dlWrap, BorderLayout.EAST);

        // the 3 grey cards: summary / details / employee details
        JPanel summary = card("SUMMARY");
        addRow(summary, "Gross Income", grossIncomeLabel);
        addRow(summary, "Benefits", benefitsLabel);
        addRow(summary, "Deductions", totalDeductionsLabel);
        addRow(summary, "Other Adjustment", otherAdjustments);
        addGap(summary);
        addRow(summary, "Net Pay", netPayLabel);

        JPanel details = card("DETAILS");
        addSection(details, "Salary Details");
        addRow(details, "Hours Worked", hoursWorked);
        addRow(details, "Hourly Rate", hourlyRate);
        addRow(details, "Overtime", overtime);
        addSection(details, "Benefits");
        addRow(details, "Phone Allowance", phoneAllowance);
        addRow(details, "Clothing Allowance", clothingAllowance);
        addRow(details, "Rice Allowance", riceSubsidy);
        addSection(details, "Deductions");
        addRow(details, "SSS Premium", sssPremiumLabel);
        addRow(details, "PhilHealth", philhealthContributionLabel);
        addRow(details, "Pag-Ibig", pagibigContributionLabel);
        addRow(details, "Withholding Tax", witholdingTaxLabel);

        JPanel empDetails = card("EMPLOYEE DETAILS");
        addRow(empDetails, "Employee ID", employeeNumber);
        addRow(empDetails, "Employee Position", position);
        addRow(empDetails, "Status", employmentStatus);
        addGap(empDetails);
        addRow(empDetails, "SSS Number", sssNumber);
        addRow(empDetails, "TIN Number", tinNumber);
        addRow(empDetails, "PhilHealth Number", philhealthNumber);
        addRow(empDetails, "Pag-Ibig Number", pagIbigNumber);

        JPanel cards = new JPanel(new GridLayout(1, 3, 16, 0));
        cards.setOpaque(false);
        cards.add(wrapTop(summary));
        cards.add(wrapTop(details));
        cards.add(wrapTop(empDetails));

        // footer
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        JLabel credits = new JLabel(Theme.CREDITS);
        credits.setForeground(Theme.TEXT_MUTED);
        credits.setFont(credits.getFont().deriveFont(11f));
        footer.add(credits, BorderLayout.WEST);
        footer.add(exitButton, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setBackground(Color.WHITE);
        content.setBorder(BorderFactory.createEmptyBorder(18, 22, 14, 22));
        content.add(downloadRow, BorderLayout.NORTH);
        content.add(cards, BorderLayout.CENTER);
        content.add(footer, BorderLayout.SOUTH);

        setContentPane(content);
        setMinimumSize(new Dimension(940, 600));
        pack();
    }

    private static JLabel valueLabel(String text) {
        JLabel l = new JLabel(text);
        l.setHorizontalAlignment(SwingConstants.RIGHT);
        return l;
    }

    private static JLabel boldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(l.getFont().deriveFont(Font.BOLD));
        return l;
    }

    private static JPanel card(String title) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(new Color(0xECEFF3));
        p.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        JLabel t = new JLabel(title);
        t.setFont(t.getFont().deriveFont(Font.BOLD, 12f));
        t.setForeground(Theme.TEXT_MUTED);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0, 0, 12, 0);
        p.add(t, c);
        p.putClientProperty("nextRow", 1);
        return p;
    }

    private static void addSection(JPanel card, String text) {
        int row = (int) card.getClientProperty("nextRow");
        JLabel l = new JLabel(text);
        l.setFont(l.getFont().deriveFont(Font.ITALIC, 12f));
        l.setForeground(Theme.TEXT_MUTED);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row;
        c.gridwidth = 2;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(row == 1 ? 0 : 12, 0, 6, 0);
        card.add(l, c);
        card.putClientProperty("nextRow", row + 1);
    }

    private static void addRow(JPanel card, String caption, JLabel value) {
        int row = (int) card.getClientProperty("nextRow");
        GridBagConstraints lc = new GridBagConstraints();
        lc.gridx = 0;
        lc.gridy = row;
        lc.anchor = GridBagConstraints.WEST;
        lc.insets = new Insets(3, 0, 3, 16);
        card.add(new JLabel(caption), lc);

        GridBagConstraints vc = new GridBagConstraints();
        vc.gridx = 1;
        vc.gridy = row;
        vc.weightx = 1;
        vc.fill = GridBagConstraints.HORIZONTAL;
        vc.insets = new Insets(3, 0, 3, 0);
        card.add(value, vc);
        card.putClientProperty("nextRow", row + 1);
    }

    private static void addGap(JPanel card) {
        int row = (int) card.getClientProperty("nextRow");
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row;
        c.gridwidth = 2;
        c.ipady = 8;
        card.add(Box.createVerticalStrut(8), c);
        card.putClientProperty("nextRow", row + 1);
    }

    private static JPanel wrapTop(JPanel card) {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(card, BorderLayout.NORTH);
        return wrap;
    }


    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        // TODO add your handling code here:
        dispose();
               
    }//GEN-LAST:event_exitButtonActionPerformed

    private void downloadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_downloadButtonActionPerformed
       try {
        //  Check if Employee ID exists
        if (empNo == null || empNo.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Employee ID is missing!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        //  Define Payslip Name (Example: "Payslip_10001_July_2024.pdf")
        String selectedMonthYear = getMonthYearString(monthSelect.getMonth() + 1, yearSelect.getYear());
        String fileName = String.format("Payslip_%s_%s.pdf", empNo, selectedMonthYear);

        //  Open File Chooser Dialog with Default File Name
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Choose Save Location");
        fileChooser.setSelectedFile(new File(fileName)); // Sets default filename
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection != JFileChooser.APPROVE_OPTION) {
            return; // Exit if user cancels
        }

        File saveFile = fileChooser.getSelectedFile(); // ✅ Get chosen file path

        //  Capture Screenshot of JFrame
        BufferedImage screenshot = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = screenshot.createGraphics();
        paint(g); // Render JFrame into image
        g.dispose();

        //  Save Screenshot as Temporary PNG
        File tempImage = new File("payslip_temp.png");
        ImageIO.write(screenshot, "png", tempImage);

        //  Create PDF Document
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(saveFile));
        document.open();

        //  Add Screenshot to PDF
        com.itextpdf.text.Image image = com.itextpdf.text.Image.getInstance("payslip_temp.png");
        image.scaleToFit(PageSize.A4.getWidth() - 40, PageSize.A4.getHeight() - 40); // Adjust size to fit page
        document.add(image);

        document.close();
        JOptionPane.showMessageDialog(this, "Payslip PDF saved successfully to:\n" + saveFile.getAbsolutePath(), 
            "Download Complete", JOptionPane.INFORMATION_MESSAGE);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error saving PDF: " + e.getMessage(), "Download Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_downloadButtonActionPerformed

    private void checkPayslipButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkPayslipButtonActionPerformed

        
    if (empNo == null || empNo.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Employee ID is missing!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Get month and year from UI controls
    int selectedMonth = monthSelect.getMonth() + 1; // JMonthChooser is 0-based (Jan=0)
    int selectedYear = yearSelect.getYear();

    try {
        // Fetch worked hours & overtime using AttendanceCalculator
        List<AttendanceRecord> allRecords = attendanceRepository.readAll();
        double[] hours = AttendanceCalculator.computeMonthlyHoursAndOT(
                allRecords,
                Integer.parseInt(empNo),
                selectedMonth,
                selectedYear
        );
  if (hours[0] == 0) {
            JOptionPane.showMessageDialog(this,
                    "No attendance recorded for this period",
                    "No Attendance",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        // Ensure hourlyRate is cleaned before parsing ✓✓
        String cleanedRate = hourlyRate.getText().replaceAll("[^0-9.]", "");
        double hourlyRateValue = Double.parseDouble(cleanedRate);

        // Compute gross income: (hoursWorked × hourlyRate) + overtimePay
        double overtimePay = SalaryComputation.computeOvertimePay(hours[1], hourlyRateValue);
        double grossIncome = SalaryComputation.computeGrossIncome(hours[0], overtimePay, hourlyRateValue);

        // Fetch Government Contributions from SalaryComputation
        double sssPremium = SalaryComputation.getSSSPremium(grossIncome);
        double philHealthPremium = SalaryComputation.getPhilHealthPremium(grossIncome);
        double pagIbigPremium = SalaryComputation.getPagIbigPremium(grossIncome);
        double withholdingTax = SalaryComputation.computeWithholdingTax(
                grossIncome - (sssPremium + philHealthPremium + pagIbigPremium));

        // Compute Total Benefits
        double totalBenefits = Double.parseDouble(benefitsLabel.getText().replaceAll("[^0-9.]", ""));

        // Compute Total Deductions
        double totalDeductions = sssPremium + philHealthPremium + pagIbigPremium + withholdingTax;

        // Compute Net Pay
        double netPay = grossIncome + totalBenefits - totalDeductions;

        // Compute Pay Date (Next Month's 15th)
        LocalDate payDate = LocalDate.of(selectedYear, selectedMonth, 1)
                                     .plusMonths(1)
                                     .withDayOfMonth(15);
        String formattedPayDate = payDate.format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"));

        // Update Payslip Fields
        hoursWorked.setText(String.format("%.2f", hours[0]));
        overtime.setText(String.format("₱%,.2f", overtimePay)); // OT at 1.5x
        grossIncomeLabel.setText(String.format("₱%,.2f", grossIncome));

        // Display Government Contributions
        sssPremiumLabel.setText(String.format("₱%,.2f", sssPremium));
        philhealthContributionLabel.setText(String.format("₱%,.2f", philHealthPremium));
        pagibigContributionLabel.setText(String.format("₱%,.2f", pagIbigPremium));
        witholdingTaxLabel.setText(String.format("₱%,.2f", withholdingTax));
        totalDeductionsLabel.setText(String.format("₱%,.2f", totalDeductions));

        // Display Net Pay
        netPayLabel.setText(String.format("₱%,.2f", netPay));

        // Display Pay Date
        payDateLabel.setText(formattedPayDate);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this,
                "Error computing payslip: " + e.getMessage(),
                "Computation Error",
                JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_checkPayslipButtonActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Payslip().setVisible(true);
            }
        });
    }

    private JLabel benefitsLabel;
    private JButton checkPayslipButton;
    private JLabel clothingAllowance;
    private JButton downloadButton;
    private JLabel employeeNameLabel;
    private JLabel employeeNumber;
    private JLabel employmentStatus;
    private JButton exitButton;
    private JLabel grossIncomeLabel;
    private JLabel hourlyRate;
    private JLabel hoursWorked;
    private JMonthChooser monthSelect;
    private JLabel netPayLabel;
    private JLabel otherAdjustments;
    private JLabel overtime;
    private JLabel pagIbigNumber;
    private JLabel pagibigContributionLabel;
    private JLabel payDateLabel;
    private JLabel philhealthContributionLabel;
    private JLabel philhealthNumber;
    private JLabel phoneAllowance;
    private JLabel position;
    private JLabel riceSubsidy;
    private JLabel sssNumber;
    private JLabel sssPremiumLabel;
    private JLabel tinNumber;
    private JLabel totalDeductionsLabel;
    private JLabel witholdingTaxLabel;
    private JYearChooser yearSelect;
}
