import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.List;
import java.time.LocalDate;
import java.util.Map;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.io.IOException;
import com.toedter.calendar.JDateChooser;
import dao.EmployeeRepository;
import dao.CsvEmployeeRepository;
import dao.AttendanceRepository;
import dao.CsvAttendanceRepository;
import model.AttendanceRecord;
import model.User;
import service.AttendanceCalculator;
import ui.Theme;

public class Attendance extends ui.AppFrame {
    private final EmployeeRepository employeeRepository = new CsvEmployeeRepository();
    private final AttendanceRepository attendanceRepository = new CsvAttendanceRepository();

    private String empNo;

    // Constructor with employee number
    public Attendance(String empNo) {
        this.empNo = empNo;
        initComponents();
        applyRoleRestrictions();
        loadEmployeeName(); // Load employee name
        employeeIDLabel.setText("Employee ID: " + empNo);

        // Load last month's records by default
        loadAttendanceRecords(empNo, LocalDate.now().minusMonths(1), LocalDate.now());

        // Restrict SUPPORT editing if viewing their own record
        String loggedInEmpId = User.getLoggedInUser().getEmployeeId().trim();
        String role = User.getLoggedInUser().getRole().trim();

        if ("SUPPORT".equalsIgnoreCase(role) && empNo.equalsIgnoreCase(loggedInEmpId)) {
            updateAttendanceButton.setVisible(false);
            jButtonSave.setVisible(false);
        }
    }

    // Default constructor
    public Attendance() {
        initComponents();
    }
    
    // Apply role restrictions for UI
    private void applyRoleRestrictions() {
        String role = User.getLoggedInUser().getRole();

        if ("EMPLOYEE".equalsIgnoreCase(role) || "HR".equalsIgnoreCase(role)) {
            if (updateAttendanceButton != null) {
                updateAttendanceButton.setVisible(false);
            }
            if (jButtonSave != null) {
                jButtonSave.setVisible(false);
            }
        }
    }

    // Load employee name into label
    private void loadEmployeeName() {
        String employeeName = getEmployeeName(empNo);
        jLabel3.setText("Employee Name: " + employeeName);
    } 

    // Retrieve employee name from EmployeeRepository
    private String getEmployeeName(String empNo) {
        return employeeRepository.findById(Integer.parseInt(empNo))
                .map(e -> e.getFirstName() + " " + e.getLastName())
                .orElse("Unknown Employee");
    }

    // Load attendance records into table
    public void loadAttendanceRecords(String empNo, LocalDate startDate, LocalDate endDate) {
        DefaultTableModel model = (DefaultTableModel) jTableAttendance.getModel();
        model.setRowCount(0); // Clear previous data

        List<String[]> records = attendanceRepository.getRecordsForEmployee(empNo, startDate, endDate);

        if (!records.isEmpty()) {
            employeeIDLabel.setText("Employee ID: " + empNo);
        }

        for (String[] row : records) {
            model.addRow(new Object[]{row[0], row[1], row[2]});
        }
    }


    


    // build the attendance window
    private void initComponents() {
        setTitle("Employee Attendance");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTableAttendance = new JTable(new DefaultTableModel(new Object[0][6], new String[]{
            "Date", "Time IN", "Time OUT", "Late", "Overtime", "Undertime"
        }));
        jScrollPane1 = new JScrollPane(jTableAttendance);
        jScrollPane1.setPreferredSize(new Dimension(820, 380));

        jLblEmpAtt = whiteLabel("Employee Attendance", Font.BOLD, 24f);
        jLabel3 = whiteLabel("Name:", Font.PLAIN, 14f);
        employeeIDLabel = whiteLabel("Employee ID:", Font.PLAIN, 14f);

        startDateLabel = new JDateChooser();
        endDateLabel = new JDateChooser();
        startDateLabel.setPreferredSize(new Dimension(130, 26));
        endDateLabel.setPreferredSize(new Dimension(130, 26));

        checkAttendanceButton = new JButton("Check Attendance");
        updateAttendanceButton = new JButton("Update Attendance");
        jButtonSave = new JButton("Save");
        jButton1 = new JButton("Close");

        checkAttendanceButton.addActionListener(this::checkAttendanceButtonActionPerformed);
        updateAttendanceButton.addActionListener(this::updateAttendanceButtonActionPerformed);
        jButtonSave.addActionListener(this::jButtonSaveActionPerformed);
        jButton1.addActionListener(this::jButton1ActionPerformed);

        for (JButton b : new JButton[]{checkAttendanceButton, updateAttendanceButton}) {
            b.setBackground(Theme.ACCENT);
            b.setForeground(Color.WHITE);
        }
        jButtonSave.setBackground(Theme.NAVY);
        jButtonSave.setForeground(Color.WHITE);
        jButton1.putClientProperty("JButton.buttonType", "borderless");
        jButton1.setForeground(Color.WHITE);

        // header
        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        jLblEmpAtt.setAlignmentX(Component.LEFT_ALIGNMENT);
        jLabel3.setAlignmentX(Component.LEFT_ALIGNMENT);
        employeeIDLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        header.add(jLblEmpAtt);
        header.add(Box.createVerticalStrut(8));
        header.add(jLabel3);
        header.add(employeeIDLabel);

        JPanel dateRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        dateRow.setOpaque(false);
        dateRow.add(whiteLabel("From", Font.PLAIN, 13f));
        dateRow.add(startDateLabel);
        dateRow.add(whiteLabel("To", Font.PLAIN, 13f));
        dateRow.add(endDateLabel);
        dateRow.add(checkAttendanceButton);
        dateRow.add(updateAttendanceButton);
        dateRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        header.add(Box.createVerticalStrut(12));
        header.add(dateRow);

        // footer
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        JLabel credits = whiteLabel(Theme.CREDITS, Font.PLAIN, 11f);
        credits.setForeground(new Color(0xC7D2E8));
        footer.add(credits, BorderLayout.WEST);
        JPanel footRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        footRight.setOpaque(false);
        footRight.add(jButtonSave);
        footRight.add(jButton1);
        footer.add(footRight, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(0, 14));
        content.setBackground(Theme.NAVY);
        content.setBorder(BorderFactory.createEmptyBorder(20, 24, 16, 24));
        content.add(header, BorderLayout.NORTH);
        content.add(jScrollPane1, BorderLayout.CENTER);
        content.add(footer, BorderLayout.SOUTH);

        setContentPane(content);
        setMinimumSize(new Dimension(900, 600));
        pack();
    }

    private static JLabel whiteLabel(String text, int style, float size) {
        JLabel l = new JLabel(text);
        l.setForeground(Color.WHITE);
        l.setFont(l.getFont().deriveFont(style, size));
        return l;
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        dispose ();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void checkAttendanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkAttendanceButtonActionPerformed
        if (startDateLabel.getDate() != null && endDateLabel.getDate() != null) {
        LocalDate startDate = startDateLabel.getDate().toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();

        LocalDate endDate = endDateLabel.getDate().toInstant()
                .atZone(java.time.ZoneId.systemDefault())
                .toLocalDate();

        // Load records into table
        loadAttendanceRecords(empNo, startDate, endDate);

        DefaultTableModel model = (DefaultTableModel) jTableAttendance.getModel();
        
         if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this,
                    "No attendance recorded for this period",
                    "No Attendance",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        try {
            // Read all records once for computation
            List<AttendanceRecord> allRecords = attendanceRepository.readAll();

            // Compute daily attendance stats using AttendanceCalculator
            for (int row = 0; row < model.getRowCount(); row++) {
                String dateStr = (String) model.getValueAt(row, 0); // Date column

                if (dateStr != null && !dateStr.trim().isEmpty()) {
                    Map<String, Double> attendanceMinutes = AttendanceCalculator.computeDailyAttendanceMinutes(
                            allRecords, Integer.parseInt(empNo), dateStr);

                    model.setValueAt(attendanceMinutes.get("Late"), row, 3);      // Late = Column 3
                    model.setValueAt(attendanceMinutes.get("Overtime"), row, 4);  // Overtime = Column 4
                    model.setValueAt(attendanceMinutes.get("Undertime"), row, 5); // Undertime = Column 5
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error computing attendance: " + e.getMessage(),
                    "Computation Error",
                    JOptionPane.ERROR_MESSAGE);
        }

        // Lock the table by rebuilding a non-editable model
        @SuppressWarnings("rawtypes")
        Vector data = model.getDataVector();

        Vector<String> columnNames = new Vector<>();
        for (int i = 0; i < model.getColumnCount(); i++) {
            columnNames.add(model.getColumnName(i));
        }

        DefaultTableModel lockedModel = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Prevent editing for all cells
            }
        };

        jTableAttendance.setModel(lockedModel);

    } else {
        JOptionPane.showMessageDialog(this,
                "Please select both start and end dates.",
                "Date Range Required",
                JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_checkAttendanceButtonActionPerformed

    private void updateAttendanceButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateAttendanceButtonActionPerformed
    DefaultTableModel model = (DefaultTableModel) jTableAttendance.getModel();

    @SuppressWarnings("rawtypes")
    Vector data = model.getDataVector();

    Vector<String> columnNames = new Vector<>();
    for (int i = 0; i < model.getColumnCount(); i++) {
        columnNames.add(model.getColumnName(i));
    }

    // Make only Time In (1) and Time Out (2) editable
    DefaultTableModel editableModel = new DefaultTableModel(data, columnNames) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return column == 1 || column == 2; // only Time In / Time Out
        }
    };

    jTableAttendance.setModel(editableModel);

    JOptionPane.showMessageDialog(this,
        "Table is now editable. You can update Time In and Time Out.",
        "Update Mode Enabled",
        JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_updateAttendanceButtonActionPerformed

    private void jButtonSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveActionPerformed
    DefaultTableModel model = (DefaultTableModel) jTableAttendance.getModel();
    List<AttendanceRecord> updatedRecords = new ArrayList<>();

    // Extract employee ID from label
    String labelText = employeeIDLabel.getText().trim();
    String empNo = labelText.replace("Employee ID:", "").trim();

    // Optional: Name labels if needed
    String firstName = "";
    String lastName = "";

    // Build updated records from Time IN/OUT
    for (int row = 0; row < model.getRowCount(); row++) {
        String date = model.getValueAt(row, 0).toString().trim();      // Column 0: Date
        String logIn = model.getValueAt(row, 1).toString().trim();     // Column 1: Time IN
        String logOut = model.getValueAt(row, 2).toString().trim();    // Column 2: Time OUT

        AttendanceRecord record = new AttendanceRecord(empNo, lastName, firstName, date, logIn, logOut);
        updatedRecords.add(record);
    }

    try {
        boolean success = attendanceRepository.updateRecords(updatedRecords);

        if (success) {
            JOptionPane.showMessageDialog(this, "Attendance records saved successfully.",
                    "Save Complete", JOptionPane.INFORMATION_MESSAGE);

            // Recalculate Late/OT/Undertime after save using AttendanceCalculator
            List<AttendanceRecord> allRecords = attendanceRepository.readAll();
            int employeeId = Integer.parseInt(empNo);

            for (int row = 0; row < model.getRowCount(); row++) {
                String date = model.getValueAt(row, 0).toString().trim();

                Map<String, Double> result = AttendanceCalculator.computeDailyAttendanceMinutes(
                        allRecords, employeeId, date);

                model.setValueAt(result.get("Late"), row, 3);       // Column 3: Late
                model.setValueAt(result.get("Overtime"), row, 4);   // Column 4: Overtime
                model.setValueAt(result.get("Undertime"), row, 5);  // Column 5: Undertime
            }
        } else {
            JOptionPane.showMessageDialog(this, "No matching records found to update.",
                    "No Changes Made", JOptionPane.WARNING_MESSAGE);
        }

    } catch (IOException | com.opencsv.exceptions.CsvValidationException e) {
        JOptionPane.showMessageDialog(this, "Error saving attendance:\n" + e.getMessage(),
                "Save Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    }//GEN-LAST:event_jButtonSaveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Attendance().setVisible(true);
            }
        });
    }

    private JButton checkAttendanceButton;
    private JLabel employeeIDLabel;
    private JDateChooser endDateLabel;
    private JButton jButton1;
    private JButton jButtonSave;
    private JLabel jLabel3;
    private JLabel jLblEmpAtt;
    private JScrollPane jScrollPane1;
    private JTable jTableAttendance;
    private JDateChooser startDateLabel;
    private JButton updateAttendanceButton;

}