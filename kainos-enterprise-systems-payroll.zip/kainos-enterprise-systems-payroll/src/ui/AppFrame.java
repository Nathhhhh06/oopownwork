package ui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.function.Supplier;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import model.Session;

/*
 * Base class for all the app windows. Two jobs:
 *  - resize/center the window so it always fits the screen (some forms are
 *    taller than a laptop screen)
 *  - keep a list of open windows so logout() can close all of them at once
 * The screens just extend this instead of JFrame.
 */
public class AppFrame extends JFrame {

    private static final double MAX_SCREEN_FRACTION = 0.92;

    // every window that is open right now (weak refs so they can still be GC'd)
    private static final Set<AppFrame> OPEN_WINDOWS =
            Collections.newSetFromMap(new WeakHashMap<>());

    // how to make a new login screen - set from LoginScreen1.main()
    // (LoginScreen1 is in the default package so we can't import it here)
    private static Supplier<JFrame> loginScreenFactory;

    static {
        Theme.setup();
    }

    private boolean prepared = false;

    protected AppFrame() {
        synchronized (OPEN_WINDOWS) {
            OPEN_WINDOWS.add(this);
        }
    }

    public static void setLoginScreenFactory(Supplier<JFrame> factory) {
        loginScreenFactory = factory;
    }

    // end the session, close every window, then reopen the login screen
    public static void logout() {
        Session.end();
        closeAll();
        if (loginScreenFactory != null) {
            loginScreenFactory.get().setVisible(true);
        }
    }

    public static void closeAll() {
        List<AppFrame> snapshot;
        synchronized (OPEN_WINDOWS) {
            snapshot = new ArrayList<>(OPEN_WINDOWS);
        }
        for (AppFrame window : snapshot) {
            window.dispose();
        }
    }

    @Override
    public void dispose() {
        synchronized (OPEN_WINDOWS) {
            OPEN_WINDOWS.remove(this);
        }
        super.dispose();
    }

    @Override
    public void setVisible(boolean visible) {
        if (visible && !prepared) {
            prepared = true;
            prepareWindow();
        }
        super.setVisible(visible);
    }

    // pack the window, shrink it if it's bigger than the screen, then center it
    protected void prepareWindow() {
        pack();

        Rectangle work = screenWorkArea();
        int maxWidth = (int) (work.width * MAX_SCREEN_FRACTION);
        int maxHeight = (int) (work.height * MAX_SCREEN_FRACTION);

        Dimension packed = getSize();

        if (packed.width > maxWidth || packed.height > maxHeight) {
            // too big for the screen - drop the content into a scroll pane
            Container content = getContentPane();
            JScrollPane scroller = new JScrollPane(content);
            scroller.setBorder(null);
            scroller.getVerticalScrollBar().setUnitIncrement(16);
            scroller.getHorizontalScrollBar().setUnitIncrement(16);
            setContentPane(scroller);
        }

        int width = Math.min(packed.width, maxWidth);
        int height = Math.min(packed.height, maxHeight);
        setSize(width, height);

        // don't let the minimum size end up bigger than what fits
        Dimension min = isMinimumSizeSet() ? getMinimumSize() : new Dimension(480, 360);
        setMinimumSize(new Dimension(Math.min(min.width, width), Math.min(min.height, height)));
        setLocationRelativeTo(null);
    }

    // screen size minus the taskbar / dock
    private static Rectangle screenWorkArea() {
        GraphicsConfiguration gc = GraphicsEnvironment
                .getLocalGraphicsEnvironment()
                .getDefaultScreenDevice()
                .getDefaultConfiguration();
        Rectangle bounds = gc.getBounds();
        Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(gc);
        return new Rectangle(
                bounds.x + insets.left,
                bounds.y + insets.top,
                bounds.width - insets.left - insets.right,
                bounds.height - insets.top - insets.bottom);
    }
}
