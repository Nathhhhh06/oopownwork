package ui;

import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import javax.swing.UIManager;

/*
 * Keeps the look and feel in one place. setup() installs FlatLaf and sets the
 * brand colours; call it once at startup before any window is built. The colour
 * constants are used instead of writing new Color(14, 49, 113) everywhere.
 */
public final class Theme {

    public static final Color NAVY = new Color(0x0E3171);
    public static final Color NAVY_DARK = new Color(0x0A2450);
    public static final Color ACCENT = new Color(0x2E6BE6);
    public static final Color SURFACE = new Color(0xFFFFFF);
    public static final Color BACKGROUND = new Color(0xF4F6FA);
    public static final Color TEXT = new Color(0x1B1F27);
    public static final Color TEXT_MUTED = new Color(0x6B7280);

    // shown at the bottom-left of every window (CP2 origin is in the README)
    public static final String CREDITS =
            "MO-IT110 OOP SY26-27  Kainos Enterprise Systems - D.Sumatra, A.Paculan, M.Arriesgado, N.Grate";

    private static boolean installed = false;

    private Theme() {
    }

    // install FlatLaf + our UI defaults. only runs once.
    public static synchronized void setup() {
        if (installed) {
            return;
        }
        installed = true;

        try {
            FlatLightLaf.setup();
        } catch (RuntimeException | LinkageError e) {
            // FlatLaf jar not on the classpath - just use the default look
            System.err.println("FlatLaf not available, using default look and feel: " + e);
        }

        UIManager.put("Button.arc", 12);
        UIManager.put("Component.arc", 12);
        UIManager.put("TextComponent.arc", 8);
        UIManager.put("ScrollBar.thumbArc", 999);
        UIManager.put("ScrollBar.width", 12);
        UIManager.put("Component.focusWidth", 1);
        UIManager.put("Table.rowHeight", 26);
        UIManager.put("TableHeader.height", 30);
        UIManager.put("Component.accentColor", NAVY);
        UIManager.put("ProgressBar.arc", 999);
    }
}
