package ui;

import java.awt.Component;
import javax.swing.JOptionPane;

/*
 * Short helpers for the JOptionPane pop-ups so they all look the same.
 * Most screens still call JOptionPane directly - new code can use these.
 */
public final class Dialogs {

    private Dialogs() {
    }

    public static void info(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Information",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void warn(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Warning",
                JOptionPane.WARNING_MESSAGE);
    }

    public static void error(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Error",
                JOptionPane.ERROR_MESSAGE);
    }

    // true only if the user clicked Yes
    public static boolean confirm(Component parent, String message, String title) {
        return JOptionPane.showConfirmDialog(parent, message, title,
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    // returns the typed text, or null if cancelled
    public static String input(Component parent, String message) {
        return JOptionPane.showInputDialog(parent, message);
    }
}
