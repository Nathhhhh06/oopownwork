import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.util.List;
import java.util.Optional;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import dao.EmployeeRepository;
import dao.CsvEmployeeRepository;
import model.Employee;
import ui.Theme;
import util.FontUtil;

public class EditEmpInfo extends ui.AppFrame {

    private final EmployeeRepository employeeRepository = new CsvEmployeeRepository();

    private int empNumToEdit;
    private Employee employeeData;
    private boolean readOnly;
    private JTextField FirstName;

   public EditEmpInfo(int empNum, boolean readOnly) {
    initComponents(); // NetBeans initializes the UI components here
    this.empNumToEdit = empNum;
    this.readOnly = readOnly;


    loadEmployeeData(empNumToEdit);

    if (readOnly) {
        disableEditing();
    }

    // Apply listeners for real-time formatting
    addKeyListenerToField(SSS);
    addKeyListenerToField(PAGIBIG);
    addKeyListenerToField(PHILHEALTH);
    addKeyListenerToField(TIN);
    addKeyListenerToField(PhoneNum);
}


    private void loadEmployeeData(int empNum) {
    // Delegate searching to the EmployeeRepository
    employeeRepository.findById(empNum).ifPresentOrElse(emp -> {
        employeeData = emp;

        // Populate Basic Info
        txtLname.setText(emp.getLastName());
        // Ensure both names are visible in the header
        Name.setText(emp.getLastName() + ", " + emp.getFirstName()); 
        
        // Populate Editable Fields
        Position.setText(emp.getPosition());
        PhoneNum.setText(emp.getPhoneNumber());
        Status.setText(emp.getStatus());
        ImmSup.setText(emp.getSupervisor());
        Address.setText(emp.getAddress());
        Birthday.setText(emp.getBirthday());

        // Populate Government IDs
        SSS.setText(emp.getSssNumber());
        PHILHEALTH.setText(emp.getPhilHealthNumber());
        TIN.setText(emp.getTinNumber());
        PAGIBIG.setText(emp.getPagIbigNumber());

        // Populate Financials (formatted to 2 decimal places)
        Salary.setText(String.format("%.2f", emp.getBasicSalary()));
        Rice.setText(String.format("%.2f", emp.getRiceSubsidy()));
        PhoneAll.setText(String.format("%.2f", emp.getPhoneAllowance()));
        ClothAll.setText(String.format("%.2f", emp.getClothingAllowance()));
        Hourly.setText(String.format("%.2f", emp.getHourlyRate()));
        
    }, () -> {
        JOptionPane.showMessageDialog(this, "Error: Employee not found!", "Error", JOptionPane.ERROR_MESSAGE);
        this.dispose();
    });
}

    /**
     * Disables editing when in read-only mode.
     * Prevents modifications to employee details while viewing.
     */
    private void disableEditing() {
    Name.setEditable(false);
    Position.setEditable(false);
    PhoneNum.setEditable(false);
    Status.setEditable(false);
    ImmSup.setEditable(false);

    // 🔄 Instead of disabling, hide the buttons completely
    Save.setVisible(false);
    Edit.setVisible(false);
}


    /**
     * Toggles field editability when switching between view and edit mode.
     * Enables or disables input fields based on the `editable` parameter.
     *
     * @param editable If true, allows editing of employee details.
     */
    private void setFieldsEditable(boolean editable) {
    // Enable/disable employee details fields
    Name.setEditable(editable);
    Position.setEditable(editable);
    PhoneNum.setEditable(editable);
    Status.setEditable(editable);
    ImmSup.setEditable(editable);
    Address.setEditable(editable);
    Birthday.setEditable(editable);

    // Enable/disable financial fields
    SSS.setEditable(editable);
    PAGIBIG.setEditable(editable);
    PHILHEALTH.setEditable(editable);
    TIN.setEditable(editable);
    Salary.setEditable(editable);
    Rice.setEditable(editable);
    PhoneAll.setEditable(editable);
    ClothAll.setEditable(editable);
    Hourly.setEditable(editable);

    // Toggle Save and Edit buttons
    Save.setEnabled(editable);
    Edit.setEnabled(!editable);
}


    /**
     * Saves updated employee details using `employeeRepository.update()`.
     * Ensures that changes are stored in the CSV file after editing.
     */
   private void saveEmployeeUpdates() {
    if (employeeData == null) {
        JOptionPane.showMessageDialog(this, "Error: No employee data loaded!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    //  Use raw input instead of applying formatIDLive() again
    employeeData.setPhoneNumber(PhoneNum.getText().trim());

    try {
        //  Save updates using EmployeeRepository
        employeeRepository.update(employeeData);

        //  Refresh employee table after saving
        if (EmployeeTable.getInstance() != null) {
            EmployeeTable.getInstance().refreshEmployeeTable();
        }

        JOptionPane.showMessageDialog(this, "Employee details updated successfully!");
        dispose();  // Close EditEmpInfo window
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error saving updates: " + e.getMessage(), "System Error", JOptionPane.ERROR_MESSAGE);
    }
}


    
    private void addKeyListenerToField(JTextField field) {
    field.addKeyListener(new KeyAdapter() {
        public void keyReleased(KeyEvent evt) {
            String rawInput = field.getText().replaceAll("[^0-9]", "");  // Remove non-numeric characters
            field.setText(formatIDLive(rawInput));  // Apply hyphen formatting
        }
    });
}
    
    private String formatIDLive(String input) {
    StringBuilder formatted = new StringBuilder();
    for (int i = 0; i < input.length(); i++) {
        formatted.append(input.charAt(i));
        if ((i + 1) % 3 == 0 && i + 1 < input.length()) {
            formatted.append("-");
        }
    }
    return formatted.toString().replaceAll("--", "-");  // ✅ Prevent double hyphens
}

    // build the view / edit employee form
    private void initComponents() {
        setTitle("Employee Details");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtLname = new JTextField();          // holds last name only; not shown
        Name = new JTextField();
        Position = new JTextField();
        Status = new JTextField();
        PhoneNum = new JTextField();
        Address = new JTextField();
        ImmSup = new JTextField();
        Birthday = new JTextField();
        PAGIBIG = new JTextField();
        PHILHEALTH = new JTextField();
        TIN = new JTextField();
        SSS = new JFormattedTextField();
        Salary = new JFormattedTextField();
        Hourly = new JFormattedTextField();
        PhoneAll = new JFormattedTextField();
        ClothAll = new JFormattedTextField();
        Rice = new JFormattedTextField();
        Save = new JButton("Save");
        Edit = new JButton("Edit");
        jButton2 = new JButton("Close");

        Name.setEditable(false);
        Name.setBorder(null);
        Name.setOpaque(false);
        Name.setFont(Name.getFont().deriveFont(Font.BOLD, 22f));
        Name.setForeground(Color.WHITE);
        Position.setEditable(false);
        Position.setBorder(null);
        Position.setOpaque(false);
        Position.setForeground(new Color(0xC7D2E8));
        Status.setEditable(false);
        Status.setBorder(null);
        Status.setOpaque(false);
        Status.setForeground(new Color(0xC7D2E8));

        Edit.addActionListener(this::EditActionPerformed);
        Save.addActionListener(this::SaveActionPerformed);
        jButton2.addActionListener(this::jButton2ActionPerformed);
        Save.setBackground(Theme.NAVY);
        Save.setForeground(Color.WHITE);
        jButton2.putClientProperty("JButton.buttonType", "borderless");

        // header
        JPanel header = new JPanel(new BorderLayout(16, 0));
        header.setBackground(Theme.NAVY);
        header.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        URL logoUrl = getClass().getResource("/logoHeader.png");
        if (logoUrl != null) {
            headerLogo = new JLabel(new ImageIcon(logoUrl));
            header.add(headerLogo, BorderLayout.WEST);
        }
        JPanel titleStack = new JPanel();
        titleStack.setOpaque(false);
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        Name.setAlignmentX(Component.LEFT_ALIGNMENT);
        Position.setAlignmentX(Component.LEFT_ALIGNMENT);
        Status.setAlignmentX(Component.LEFT_ALIGNMENT);
        titleStack.add(Name);
        titleStack.add(Position);
        titleStack.add(Status);
        header.add(titleStack, BorderLayout.CENTER);

        // body - contact + government IDs side by side, then compensation
        JPanel contact = section("Contact");
        addRow(contact, "Phone Number", PhoneNum, 1);
        addRow(contact, "Address", Address, 2);
        addRow(contact, "Immediate Supervisor", ImmSup, 3);
        addRow(contact, "Birthday", Birthday, 4);

        JPanel govt = section("Government IDs");
        addRow(govt, "SSS", SSS, 1);
        addRow(govt, "PhilHealth", PHILHEALTH, 2);
        addRow(govt, "TIN", TIN, 3);
        addRow(govt, "Pag-IBIG", PAGIBIG, 4);

        JPanel topRow = new JPanel(new GridLayout(1, 2, 20, 0));
        topRow.setOpaque(false);
        topRow.add(contact);
        topRow.add(govt);

        JPanel comp = section("Compensation");
        addRow(comp, "Basic Salary", Salary, 1);
        addRow(comp, "Hourly Rate", Hourly, 2);
        addRow(comp, "Rice Subsidy", Rice, 3);
        addRow(comp, "Phone Allowance", PhoneAll, 4);
        addRow(comp, "Clothing Allowance", ClothAll, 5);

        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBorder(BorderFactory.createEmptyBorder(20, 24, 12, 24));
        topRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        comp.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(topRow);
        body.add(Box.createVerticalStrut(18));
        body.add(comp);

        // footer
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(BorderFactory.createEmptyBorder(8, 24, 12, 24));
        JLabel credits = new JLabel(Theme.CREDITS);
        credits.setForeground(Theme.TEXT_MUTED);
        credits.setFont(credits.getFont().deriveFont(11f));
        footer.add(credits, BorderLayout.WEST);
        JPanel actions = new JPanel();
        actions.setLayout(new BoxLayout(actions, BoxLayout.X_AXIS));
        actions.add(Edit);
        actions.add(Box.createHorizontalStrut(8));
        actions.add(Save);
        actions.add(Box.createHorizontalStrut(8));
        actions.add(jButton2);
        footer.add(actions, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(Color.WHITE);
        content.add(header, BorderLayout.NORTH);
        content.add(body, BorderLayout.CENTER);
        content.add(footer, BorderLayout.SOUTH);

        setContentPane(content);
        setMinimumSize(new Dimension(720, 620));
        pack();
    }

    private static JPanel section(String title) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        JLabel t = new JLabel(title);
        t.setFont(t.getFont().deriveFont(Font.BOLD, 13f));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0, 0, 8, 0);
        p.add(t, c);
        return p;
    }

    private static void addRow(JPanel section, String label, JTextField field, int row) {
        GridBagConstraints lc = new GridBagConstraints();
        lc.gridx = 0; lc.gridy = row;
        lc.anchor = GridBagConstraints.WEST;
        lc.insets = new Insets(4, 0, 4, 12);
        section.add(new JLabel(label), lc);

        GridBagConstraints fc = new GridBagConstraints();
        fc.gridx = 1; fc.gridy = row;
        fc.weightx = 1;
        fc.fill = GridBagConstraints.HORIZONTAL;
        fc.insets = new Insets(4, 0, 4, 0);
        field.setPreferredSize(new Dimension(200, field.getPreferredSize().height));
        section.add(field, fc);
    }

    private void TINActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TINActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TINActionPerformed

    private void PHILHEALTHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PHILHEALTHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PHILHEALTHActionPerformed

    private void PAGIBIGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PAGIBIGActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PAGIBIGActionPerformed

    private void EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditActionPerformed
        // TODO add your handling code here:
        setFieldsEditable(true); //Unlock fields for editinG
 
    }//GEN-LAST:event_EditActionPerformed

    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveActionPerformed
                                    
    if (employeeData == null) return;

    try {
        // 1. Update Text Fields (using .trim() to keep data clean)
        employeeData.setPhoneNumber(PhoneNum.getText().trim());
        employeeData.setAddress(Address.getText().trim());
        employeeData.setSupervisor(ImmSup.getText().trim());
        employeeData.setPosition(Position.getText().trim());
        employeeData.setStatus(Status.getText().trim());
        
        // 2. Update Government IDs
        employeeData.setSssNumber(SSS.getText().trim());
        employeeData.setPhilHealthNumber(PHILHEALTH.getText().trim());
        employeeData.setTinNumber(TIN.getText().trim());
        employeeData.setPagIbigNumber(PAGIBIG.getText().trim());

        // 3. Use parseDoubleSafe to handle currency/empty fields
        employeeData.setBasicSalary(CsvEmployeeRepository.parseDoubleSafe(Salary.getText(), employeeData.getBasicSalary()));
        employeeData.setHourlyRate(CsvEmployeeRepository.parseDoubleSafe(Hourly.getText(), employeeData.getHourlyRate()));
        employeeData.setRiceSubsidy(CsvEmployeeRepository.parseDoubleSafe(Rice.getText(), employeeData.getRiceSubsidy()));
        employeeData.setPhoneAllowance(CsvEmployeeRepository.parseDoubleSafe(PhoneAll.getText(), employeeData.getPhoneAllowance()));
        employeeData.setClothingAllowance(CsvEmployeeRepository.parseDoubleSafe(ClothAll.getText(), employeeData.getClothingAllowance()));

        // 4. Save to CSV via Handler
        employeeRepository.update(employeeData);
        
        // 5. UI Feedback and Refresh
        JOptionPane.showMessageDialog(this, "Employee record updated successfully!");
        
        if (EmployeeTable.getInstance() != null) {
            EmployeeTable.getInstance().refreshEmployeeTable();
        }

        setFieldsEditable(false);
        dispose();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error saving updates: " + e.getMessage(), "System Error", JOptionPane.ERROR_MESSAGE);
    }
}

/**
 * Helper method to safely parse double values, preserving the existing value if input is invalid or empty.
 */
private double parseDouble(String value, double currentValue) {
    if (value == null || value.trim().isEmpty()) {
        return currentValue; // Added return for empty/null case
    }
    try {
        // Remove currency symbols and commas before parsing
        String cleanValue = value.trim().replaceAll("[₱,]", "");
        return Double.parseDouble(cleanValue);
    } catch (NumberFormatException e) {
        System.err.println("ERROR: Invalid number format: " + value);
        return currentValue; // Return existing value if parsing fails
    }

    }//GEN-LAST:event_SaveActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        dispose ();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void SalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalaryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SalaryActionPerformed

    private void ImmSupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImmSupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ImmSupActionPerformed

    private void PhoneNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PhoneNumActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PhoneNumActionPerformed

    private void BirthdayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BirthdayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BirthdayActionPerformed

    private void AddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AddressActionPerformed

    private void NameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NameActionPerformed

    private void PositionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PositionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PositionActionPerformed

    private void StatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StatusActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                String selectedEmpNum = null;
          
                new EditEmpInfo(Integer.parseInt(selectedEmpNum), true).setVisible(true);
            }
        });
    }

    private JTextField Address;
    private JTextField Birthday;
    private JFormattedTextField ClothAll;
    private JButton Edit;
    private JFormattedTextField Hourly;
    private JTextField ImmSup;
    private JTextField Name;
    private JTextField PAGIBIG;
    private JTextField PHILHEALTH;
    private JFormattedTextField PhoneAll;
    private JTextField PhoneNum;
    private JTextField Position;
    private JFormattedTextField Rice;
    private JFormattedTextField SSS;
    private JFormattedTextField Salary;
    private JButton Save;
    private JTextField Status;
    private JTextField TIN;
    private JLabel headerLogo;
    private JButton jButton2;
    private JTextField txtLname;
}
