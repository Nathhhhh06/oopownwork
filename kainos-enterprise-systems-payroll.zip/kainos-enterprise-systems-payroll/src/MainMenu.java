/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author singh
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import com.opencsv.exceptions.CsvValidationException;
import dao.EmployeeRepository;
import dao.CsvEmployeeRepository;
import dao.AttendanceRepository;
import dao.CsvAttendanceRepository;
import model.Employee;
import model.User;
import ui.Theme;
import util.FontUtil;



/**
 * The MainMenu class represents the main dashboard after successful login.
 * It personalizes the greeting and provides access to core modules.
 */
public class MainMenu extends ui.AppFrame {

    private final EmployeeRepository employeeRepository = new CsvEmployeeRepository();
    private final AttendanceRepository attendanceRepository = new CsvAttendanceRepository();

    // Hold the logged-in user's info
    private User currentUser;

    // GUI modules
    private EmployeeTable femptable;
    private Payslip fpayslip;
    private Attendance fattendance;

    /**
     * Default constructor (optional for testing or fallback)
     */
    public MainMenu() {
        initComponents();
        initModules();
    }

    /**
     * Constructor with user info passed from Login
     */
    public MainMenu(User user) {
        this.currentUser = user;
        initComponents();
        initModules();

        if (jLabelWelcome != null && user != null) {
            jLabelWelcome.setText("Welcome, " + user.getFirstName() + " " + user.getLastName());
        }
    }

    /**
     * Initializes form modules (you can expand this if needed)
     */
    private void initModules() {
        femptable = new EmployeeTable();
        fpayslip = new Payslip();
        fattendance = new Attendance();
    }
    
    private void openAttendanceForSupervisedEmployee() {
    String supervisorName = User.getLoggedInUser().getLastName().trim() + "  " + User.getLoggedInUser().getFirstName().trim();
    List<Employee> supervised = new ArrayList<>();

    for (Employee emp : employeeRepository.findAll()) {
        if (emp.getSupervisor().trim().equalsIgnoreCase(supervisorName)) {
            supervised.add(emp);
        }
    }

    if (supervised.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No supervised employees found.", "Info", JOptionPane.INFORMATION_MESSAGE);
        return;
    }

    String[] namesWithIDs = supervised.stream()
        .map(e -> e.getFirstName() + " " + e.getLastName() + " (" + e.getEmployeeNumber() + ")")
        .toArray(String[]::new);

    String selection = (String) JOptionPane.showInputDialog(
        this,
        "Select an employee:",
        "Attendance Viewer",
        JOptionPane.PLAIN_MESSAGE,
        null,
        namesWithIDs,
        namesWithIDs[0]
    );

    if (selection != null && !selection.trim().isEmpty()) {
        String empId = selection.replaceAll(".*\\((\\d+)\\).*", "$1"); // Extract numeric ID
        new Attendance(empId).setVisible(true);
    }
}

    
    // In EditEmpInfo.java

    // build the dashboard UI
    private void initComponents() {
        setTitle("MotorPH Payroll - Dashboard");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabelWelcome = new JLabel("Welcome");
        jButtonTimein = new JButton("Time In");
        jButtonTimeout = new JButton("Time Out");
        headerLogo = new JLabel();
        jButtonEmployee = new JButton("Employee Information");
        jButtonPayslip = new JButton("Payslip");
        jButtonAttendance = new JButton("Attendance");
        jButtonExit2 = new JButton("Sign Out");
        jLabel1 = new JLabel(Theme.CREDITS);

        jButtonTimein.addActionListener(this::jButtonTimeinActionPerformed);
        jButtonTimeout.addActionListener(this::jButtonTimeoutActionPerformed);
        jButtonEmployee.addActionListener(this::jButtonEmployeeActionPerformed);
        jButtonPayslip.addActionListener(this::jButtonPayslipActionPerformed);
        jButtonAttendance.addActionListener(this::jButtonAttendanceActionPerformed);
        jButtonExit2.addActionListener(this::jButtonExit2ActionPerformed);

        setContentPane(buildContent());
        setMinimumSize(new Dimension(760, 560));
        pack();
    }

    private JPanel buildContent() {
        JPanel content = new JPanel(new BorderLayout());
        content.add(buildHeader(), BorderLayout.NORTH);
        content.add(buildNavArea(), BorderLayout.CENTER);
        content.add(buildFooter(), BorderLayout.SOUTH);
        return content;
    }

    // top bar - welcome text on the left, time in/out on the right
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.NAVY);
        header.setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 24));

        jLabelWelcome.setForeground(Color.WHITE);
        jLabelWelcome.setFont(FontUtil.getKinetikaFont(22f));

        URL logoUrl = getClass().getResource("/logoHeader.png");
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        left.setOpaque(false);
        if (logoUrl != null) {
            headerLogo.setIcon(new ImageIcon(logoUrl));
            left.add(headerLogo);
        }
        left.add(jLabelWelcome);
        header.add(left, BorderLayout.WEST);

        JPanel clock = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        clock.setOpaque(false);
        styleAccentButton(jButtonTimein);
        styleAccentButton(jButtonTimeout);
        clock.add(jButtonTimein);
        clock.add(jButtonTimeout);
        header.add(clock, BorderLayout.EAST);

        return header;
    }

    // the 3 main menu buttons, stacked in the middle
    private JPanel buildNavArea() {
        JPanel body = new JPanel(new GridBagLayout());
        body.setBackground(Color.WHITE);

        JPanel column = new JPanel();
        column.setOpaque(false);
        column.setLayout(new BoxLayout(column, BoxLayout.Y_AXIS));

        for (JButton nav : new JButton[]{jButtonEmployee, jButtonPayslip, jButtonAttendance}) {
            styleNavButton(nav);
            column.add(nav);
            column.add(Box.createVerticalStrut(16));
        }
        column.remove(column.getComponentCount() - 1); // trailing strut

        body.add(column);
        return body;
    }

    // bottom strip - credits on the left, sign out on the right
    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBorder(BorderFactory.createEmptyBorder(10, 24, 10, 24));

        jLabel1.setForeground(Theme.TEXT_MUTED);
        jLabel1.setFont(jLabel1.getFont().deriveFont(11f));
        footer.add(jLabel1, BorderLayout.WEST);

        jButtonExit2.setForeground(new Color(0xB00020));
        jButtonExit2.putClientProperty("JButton.buttonType", "borderless");
        footer.add(jButtonExit2, BorderLayout.EAST);

        return footer;
    }

    private static void styleNavButton(JButton b) {
        b.setBackground(Theme.NAVY);
        b.setForeground(Color.WHITE);
        b.setFont(b.getFont().deriveFont(Font.BOLD, 15f));
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setHorizontalAlignment(SwingConstants.CENTER);
        Dimension size = new Dimension(300, 52);
        b.setPreferredSize(size);
        b.setMaximumSize(size);
        b.setMinimumSize(size);
    }

    private static void styleAccentButton(JButton b) {
        b.setBackground(Theme.ACCENT);
        b.setForeground(Color.WHITE);
    }

    private void jButtonTimeinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTimeinActionPerformed
        if (currentUser != null) {
        try {
            attendanceRepository.logTimeIn(currentUser);
            JOptionPane.showMessageDialog(this,
                "Time-in recorded successfully.",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                "Error logging time in: " + e.getMessage(),
                "Log Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    } else {
        JOptionPane.showMessageDialog(this,
            "User session not found. Please log in again.",
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
        
    }//GEN-LAST:event_jButtonTimeinActionPerformed

    private void jButtonEmployeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEmployeeActionPerformed
                                    
    String role = User.getLoggedInUser().getRole();

    if ("EMPLOYEE".equalsIgnoreCase(role)) {
        int empId = Integer.parseInt(User.getLoggedInUser().getEmployeeId());
        EditEmpInfo editInfo = new EditEmpInfo(empId, true);
        editInfo.setVisible(true);
        editInfo.setLocationRelativeTo(null);
    } else if ("SUPPORT".equalsIgnoreCase(role)) {
        String supervisorId = User.getLoggedInUser().getEmployeeId();
        EmployeeTable filteredTable = new EmployeeTable(supervisorId, "Employee Information");
        filteredTable.setVisible(true);
        filteredTable.setLocationRelativeTo(null);
    } else {
        femptable.setVisible(true);
        femptable.setLocationRelativeTo(null);
    }
    }//GEN-LAST:event_jButtonEmployeeActionPerformed

    private void jButtonPayslipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPayslipActionPerformed
    String role = User.getLoggedInUser().getRole();

    if ("ADMIN".equalsIgnoreCase(role)) {
        //  Admin users get full employee list view
        EmployeeTable employeeTable = new EmployeeTable(null, "Employee Payslip");
        employeeTable.setVisible(true);
        employeeTable.setLocationRelativeTo(null);
        return;
    }

    if ("EMPLOYEE".equalsIgnoreCase(role) || 
        "SUPPORT".equalsIgnoreCase(role) || 
        "HR".equalsIgnoreCase(role)) {
        
        String empId = User.getLoggedInUser().getEmployeeId();
        new Payslip(empId).setVisible(true);
    } else {
        String input = JOptionPane.showInputDialog(
            this,
            "Enter Employee Number:",
            "Generate Payslip",
            JOptionPane.QUESTION_MESSAGE
        );

        if (input != null && !input.trim().isEmpty()) {
            new Payslip(input.trim()).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Employee Number is required.", "Input Error", JOptionPane.WARNING_MESSAGE);
        }
    }
    }//GEN-LAST:event_jButtonPayslipActionPerformed

    private void jButtonExit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExit2ActionPerformed
     int confirm = JOptionPane.showConfirmDialog(this,
        "Are you sure you want to log out?",
        "Logout Confirmation",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);

    if (confirm == JOptionPane.YES_OPTION) {
        // closes every open window and goes back to the login screen
        ui.AppFrame.logout();
    }
    }//GEN-LAST:event_jButtonExit2ActionPerformed

    private void jButtonTimeoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTimeoutActionPerformed
        if (currentUser != null) {
        try {
            attendanceRepository.logTimeOut(currentUser);
            JOptionPane.showMessageDialog(this,
                "Time-out recorded successfully.",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException | com.opencsv.exceptions.CsvValidationException e) {
            JOptionPane.showMessageDialog(this,
                "Error logging time out: " + e.getMessage(),
                "Log Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    } else {
        JOptionPane.showMessageDialog(this,
            "User session not found. Please log in again.",
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jButtonTimeoutActionPerformed

    private void jButtonAttendanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAttendanceActionPerformed
                                                
    String role = User.getLoggedInUser().getRole().trim();

    if ("EMPLOYEE".equalsIgnoreCase(role) || "HR".equalsIgnoreCase(role)) {
        String empId = User.getLoggedInUser().getEmployeeId();
        Attendance attendanceWindow = new Attendance(empId);
        attendanceWindow.setVisible(true);
        attendanceWindow.setLocationRelativeTo(null);

    } else if ("SUPPORT".equalsIgnoreCase(role) || "ADMIN".equalsIgnoreCase(role)) {
        String supervisorFullName = User.getLoggedInUser().getLastName().trim() + " " +
                                    User.getLoggedInUser().getFirstName().trim();

        EmployeeTable attendanceTable = new EmployeeTable(supervisorFullName, "Employee Attendance");
        attendanceTable.setVisible(true);
        attendanceTable.setLocationRelativeTo(null);
    } else {
        // Optional fallback for unknown roles
        JOptionPane.showMessageDialog(this,
            "Your role does not support viewing the Attendance screen.",
            "Access Denied",
            JOptionPane.WARNING_MESSAGE);
    }

    }//GEN-LAST:event_jButtonAttendanceActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        ui.Theme.setup();  // look and feel

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }

    private JLabel headerLogo;
    private JButton jButtonAttendance;
    private JButton jButtonEmployee;
    private JButton jButtonExit2;
    private JButton jButtonPayslip;
    private JButton jButtonTimein;
    private JButton jButtonTimeout;
    private JLabel jLabel1;
    private JLabel jLabelWelcome;
}
