# OOP Readiness Plan — Payroll System

**Date:** 2026-09-01
**Status:** Draft for team discussion
**Repo:** `kainos-enterprise-systems-payroll` (formerly `MotorPHGUI`)

---

## Where we are

The codebase was reorganised into layers (commit `cd9d9c8`):

- `model/` — `Employee`, `User`, `AttendanceRecord` (plain data)
- `dao/` — `EmployeeRepository` / `UserRepository` / `AttendanceRepository` interfaces, each with a `Csv*Repository` implementation
- `service/` — `SalaryComputation`, `AttendanceCalculator` (calculation)
- `util/` — `AppPaths`, `PasswordHasher`, `FontUtil`
- 8 Swing screens stay in the default package

Good foundation: storage is behind interfaces, screens depend on the interface type, `Optional` used for lookups, passwords hashed (PBKDF2), data paths resolved via `AppPaths`.

**Gap:** almost nothing demonstrates the OOP concepts a rubric grades — no inheritance, no polymorphism, domain logic still lives in bags of `static` methods, models pass around `double[]` / `Map<String,Double>` instead of real objects.

### UI foundation shell — DONE (2026-09-01)

A first inheritance hierarchy plus the UI baseline is now in place:

- New `ui/` package: `Theme` (FlatLaf look and feel + brand palette, one place), `AppFrame`
  (a `JFrame` subclass), `Dialogs` (JOptionPane wrappers).
- All 8 screens now `extends ui.AppFrame` instead of `javax.swing.JFrame`. `AppFrame` clamps
  each window to ≤92% of the screen's usable area, wraps oversized fixed-layout forms in a
  scroll pane, sets a minimum size, and centres — fixes windows opening off-screen on small
  laptops / high-DPI displays.
- Per-screen "find Nimbus" loops replaced with `ui.Theme.setup()`.
- `flatlaf-3.4.1.jar` vendored in `libs/`; `build.xml` gained a `-post-jar` step so the built
  jar bundles its `Class-Path` and runs standalone outside NetBeans.

**NetBeans note:** the `.form` files still say `JFrameFormInfo`. `AppFrame` IS-A `JFrame`, so
the designer still works, but if a teammate hits a form-editor warning, use *Set Superclass*
in NetBeans (or just edit the `.java` — that is what the rest of the team already does).

**Not done here (deliberately):** the screen layouts themselves are still `AbsoluteLayout`
with fixed pixel positions. True resizable layouts = Tier 2 item 8 territory.

### Session + logout + per-screen redesign — IN PROGRESS (2026-09-01)

- **Logout bug fixed.** New `model/Session` (replaces the `User.loggedInUser` static;
  `User.getLoggedInUser()` now delegates to it). `ui/AppFrame` keeps a registry of every open
  window and exposes `AppFrame.logout()` — ends the session, disposes **all** open windows
  (main + any child windows), then reopens the login screen. `MainMenu`'s logout button calls
  it. Previously child windows stayed open after logout.
- **Login screen rebuilt.** `LoginScreen1` is now a hand-written layout (`BorderLayout` +
  `GridBagLayout`, resizable, FlatLaf placeholders/borderless link button). Its `.form` file
  was **deleted** — it is a normal Swing class now, not a NetBeans form.
- **Screen rebuilds (replace fixed-pixel `initComponents()` with real layouts, keep handler
  bodies, delete `.form`):**
  - [x] LoginScreen1 — BorderLayout + GridBagLayout
  - [x] MainMenu — BorderLayout header/nav/footer, centred nav column
  - [x] EmployeeTable — BorderLayout (title / table / side buttons / footer)
  - [x] AddEmployee — GridBag form, two sections, brand strip
  - [x] Attendance — BorderLayout, BoxLayout header, table, footer
  - [x] EditEmpInfo — two-section GridBag form + compensation section, navy header
  - [x] ViewEmpInfo — rebuilt as a stub (it is constructed but never actually shown; the
        "View" action opens EditEmpInfo read-only instead)
  - [x] Payslip — three cards (Summary / Details / Employee Details) in a GridLayout,
        header with cutoff pickers, fixed the label/value overlap in Employee Details
  All 8 `.form` files deleted. Every rebuilt window uses `pack()` on a real layout, so it opens
  sized to its own content — nothing clipped at the default size. `ui.AppFrame` still clamps to
  the screen and adds a scroll pane only if a window would exceed it.

- **Footer credit** on every window is now `ui.Theme.CREDITS`:
  "TEAM PETIX · Sumatra, D. — CP2 project, used with permission (handover in progress)".
  One constant, change it in one place.

**Decision to confirm with the team:** we are moving **off the NetBeans form designer** for the
GUI. Editing `AbsoluteLayout` in the designer was not helping, and hand-written layouts are
resizable and reviewable in a normal diff. Anyone who was using the designer needs to know.

---

## Proposed work

Grouped by priority. Each item needs an **owner** and an **estimate** — fill in during the meeting.

### Tier 1 — core OOP demonstrations (highest rubric weight)

| # | Item | Files | Owner | Est. |
|---|------|-------|-------|------|
| 1 | **Inheritance hierarchy.** `abstract class Person` (id, firstName, lastName, `getFullName()`) as the base for `Employee` and `User` — they already duplicate the name fields. | `model/Person.java` (new), `model/Employee.java`, `model/User.java` | | |
| 2 | **Role subclasses + polymorphism.** `User` → `AdminUser` / `HrUser` / `EmployeeUser`, each with a polymorphic permission method (e.g. `canAccess(...)`). Replace the role-string branching in `LoginScreen1` (lines ~295–301, already has `// optional: HR/Admin interface` TODO comments). | `model/User.java` + subclasses, `LoginScreen1.java` | | |
| 3 | **`Deduction` polymorphic hierarchy.** Convert `SalaryComputation` (10 `static` methods) into `interface Deduction { BigDecimal computeFor(PayrollContext) }` with `SssDeduction`, `PhilHealthDeduction`, `PagIbigDeduction`, `WithholdingTax`. Payroll iterates `List<Deduction>`. Best polymorphism showcase in the project. | `service/SalaryComputation.java`, new `service/deduction/*` | | |
| 4 | **Value objects instead of primitive bundles.** `AttendanceCalculator.computeMonthlyHoursAndOT` returns `double[]`; `computeDailyAttendanceMinutes` returns `Map<String,Double>`. Introduce `WorkHours` and `DailyAttendance`. Add a `Payslip` domain object holding the breakdown (Payslip.java currently juggles ~10 loose `double` locals). | `service/AttendanceCalculator.java`, `Payslip.java`, new model types | | |

### Tier 2 — OOP hygiene

| # | Item | Files | Owner | Est. |
|---|------|-------|-------|------|
| 5 | **Tame `Employee`.** 20-arg constructor + 18 setters. Group into composed value objects (`GovernmentIds`, `Allowances`, `Compensation`) and/or a Builder. | `model/Employee.java` | | |
| 6 | **`equals()` / `hashCode()` / `toString()`** on all model classes — none have them. | `model/*` | | |
| 7 | **Money as `BigDecimal`**, not `double`, throughout payroll. Optional `Money` type. | `service/*`, `model/*`, `Payslip.java` | | |
| 8 | **Constructor injection of repositories** into screens instead of `new CsvEmployeeRepository()` inline (`MainMenu.java:30`, `Payslip.java:36`). Makes screens testable. | all screens | | |
| 9 | **Replace `User.loggedInUser` static global** (`User.java:13`) with a `Session` object. | `model/User.java`, callers | | |

### Tier 3 — supporting

| # | Item | Files | Owner | Est. |
|---|------|-------|-------|------|
| 10 | **JUnit + Ant `test` target** (no Maven — add jar to `libs/`), then tests for the deduction logic and `AttendanceCalculator`. | `build.xml`, `libs/`, new `test/` | | |
| 11 | **Stop swallowing errors in payroll math.** `SalaryComputation.getSSSPremium` catches `Exception` and returns `0.0` — a bad SSS table silently under-pays. | `service/SalaryComputation.java` | | |
| 12 | **Flesh out `README.md`** — architecture, UML class diagram, explicit "OOP principles demonstrated" section. Documentation is usually graded. | `README.md`, `docs/` | | |
| 13 | **Move `parseDoubleSafe`** (a UI helper) out of `CsvEmployeeRepository:85`. | `dao/CsvEmployeeRepository.java`, `util/` | | |

---

## Open security item to decide on (from setup review)

Plaintext seed passwords (`mgarcia`/`Burger123`, `alim`/`Pizza123`, …) are in `src/data/employee_logins.csv` **and in git history** on:

- the old public twin repo `github.com/clu3l3ss24/MotorPHGUI`
- this repo `github.com/ranselcrackers/kainos-enterprise-systems-payroll` (currently **private**)

Runtime hashing only migrates the working-copy CSV as accounts log in — it does **not** scrub history. **Decision needed before the repo is made public, shared with graders, or given collaborators:** rewrite history to redact the CSV / replace it with a `.example` file, and rotate any real passwords.

---

## Discussion points for the meeting

- [ ] Do we do all of Tier 1, or is a subset enough for the deliverable? What does the rubric actually require?
- [ ] Scope of #3 — full `Deduction` hierarchy, or a lighter version?
- [ ] Do we move the Swing screens into a `ui/` package, or leave NetBeans-form classes in the default package? (deferred once already)
- [ ] Who takes which Tier 1 item?
- [ ] Timeline / milestones vs. submission date.
- [ ] Branch strategy — one branch per person, or per feature?
- [ ] Handling the plaintext-credentials history item above.

---

## Notes / decisions

_(add meeting outcomes here)_
