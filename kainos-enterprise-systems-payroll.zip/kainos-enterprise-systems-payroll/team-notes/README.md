# Team Notes

Planning docs, meeting notes, and design discussions for the payroll system.

Not code — this directory is for the team to align before/while building.

## Index

- [2026-09-01 — OOP Readiness Plan](2026-09-01-oop-readiness-plan.md) — assessment of what's needed to prepare the codebase for the OOP deliverable, with a tiered task list for the team to assign and estimate.

## Conventions

- One file per meeting or topic, prefixed with the date: `YYYY-MM-DD-topic.md`.
- Add new files to the index above.
- Record decisions in the doc they relate to, under a "Notes / decisions" heading.
