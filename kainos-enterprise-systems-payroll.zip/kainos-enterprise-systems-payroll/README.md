# MotorPH Payroll System

**Kainos Enterprise Systems** — MO-IT110 Object-Oriented Programming
D.R. Sumatra · A. Paculan · M. Arriesgado · N. Grate

📄 **[Sumatra's individual Milestone 1 progress report](https://kainos-payroll-documentation.lr-drsumatra.workers.dev/)** —
codebase modernization journey, the Week 2–6 OOP design walkthrough, and two design
corrections caught along the way. Built from [`docs/`](docs/), deployed on Cloudflare
(see [`docs/README.md`](docs/README.md) for how to redeploy it).

---

A Java desktop payroll application that automates salary processing for **MotorPH**. It computes
employee wages, overtime, benefits, and statutory contributions (**SSS**, **PhilHealth**,
**Pag-IBIG**) and withholding tax, and generates printable payslips. Employee records and
attendance tracking are built in so payroll runs off a single, consistent data set.

---

## Features

- **Authentication** — username/password login with salted **PBKDF2** password hashing, a
  security-question recovery flow, and role-based access (`ADMIN`, `HR`, `SUPPORT`, `EMPLOYEE`).
- **Employee records** — add, view, edit, and delete employees; each employee has personal
  details, government IDs, compensation, and allowances.
- **Attendance** — per-user time in / time out logging, with automatic computation of late,
  undertime, and overtime minutes against an 08:00–17:00 office day (10-minute grace period).
- **Payroll & payslips** — monthly gross/net computation, statutory deductions from a
  configurable SSS contribution table, TRAIN-law withholding tax brackets, and PDF/print output.

---

## Tech stack

| | |
|---|---|
| Language | Java 21 (`--enable-preview`) |
| UI | Java Swing (hand-written layouts) + [FlatLaf](https://www.formdev.com/flatlaf/) look and feel |
| Build | Apache Ant (NetBeans `build.xml`) |
| Storage | Flat CSV files (no database) |
| Libraries | `opencsv 5.9`, `commons-lang3 3.12.0`, `jcalendar 1.4`, `itextpdf 5.5.13.3`, `AbsoluteLayout`, `flatlaf 3.4.1` |

All third-party jars are vendored in [`libs/`](libs/) — no network access is needed to build.

---

## Architecture

The code is organised into layers so that UI, business rules, and storage stay independent. The
domain layer (`model/`, `service/`) is being refactored toward the **OOP design** described in the
next section.

| Package | Responsibility | Key types |
|---------|----------------|-----------|
| `model/` | Plain domain data | `Employee`, `User`, `AttendanceRecord`, `Session` |
| `dao/` | Storage abstraction — callers depend on the interface, not the CSV | `EmployeeRepository`, `UserRepository`, `AttendanceRepository` + their `Csv*Repository` implementations |
| `service/` | Business calculations | `SalaryComputation`, `AttendanceCalculator` |
| `ui/` | Shared window + theme infrastructure | `AppFrame`, `Theme`, `Dialogs` |
| `util/` | Cross-cutting helpers | `AppPaths`, `PasswordHasher`, `FontUtil` |
| *(default package)* | Swing screens | `LoginScreen1`, `MainMenu`, `AddEmployee`, `EditEmpInfo`, `EmployeeTable`, `ViewEmpInfo`, `Attendance`, `Payslip` |

Because every screen talks to a repository **interface** (e.g. `LoginScreen1` holds a
`UserRepository`, not a `CsvUserRepository`), the CSV backing store can be swapped for a
database later without touching UI code.

Every screen extends **`ui.AppFrame`** (a `JFrame` subclass) rather than `JFrame` directly — the
project's first real inheritance hierarchy. `AppFrame` installs the look and feel once, and the
first time a window is shown it clamps the window to the screen's usable area, adds scrollbars if
the content is still larger than the display, centres it, and (via `logout()`) can close every
open window at once. `ui.Theme` is the single place the FlatLaf look and feel, the brand palette,
and the footer credit line are defined. The screens were rebuilt with hand-written layouts
(`BorderLayout` / `GridBagLayout` / `BoxLayout`) — the NetBeans `.form` files were removed.

`util.AppPaths` resolves the `src/data/*.csv` files by walking up from the running code's
location, so the app works whether it is launched from NetBeans, from the built jar in
`dist/`, or from any other working directory.

### Project structure

```
src/
├── model/            Employee, User, AttendanceRecord, Session
├── dao/              *Repository interfaces + Csv*Repository implementations
├── service/          SalaryComputation, AttendanceCalculator
├── ui/               AppFrame (shared base window), Theme, Dialogs
├── util/             AppPaths, PasswordHasher, FontUtil
├── data/             CSV data files (see below)
└── *.java            Swing screens (entry point: LoginScreen1)
libs/                 vendored third-party jars
build.xml             Ant build (NetBeans-generated, + a -post-jar step)
team-notes/           planning & design docs
```

---

## OOP design (Milestone 1)

The Milestone 1 design package — CRC cards, method dictionary, and architecture overview — models
the payroll domain around a small class hierarchy. **This is the target design; it is implemented
in Milestone 2.** The current code still has `model.Employee` as one concrete class and
`service.SalaryComputation` as static methods; the refactor backlog is in
[`team-notes/2026-09-01-oop-readiness-plan.md`](team-notes/2026-09-01-oop-readiness-plan.md).

### Class model

| Class | Responsibility | Extends / collaborates |
|---|---|---|
| `Employee` *(abstract)* | Holds and protects one employee's identity and pay data — `employeeId`, `firstName`, `lastName`, `monthlySalary`, `hourlyRate`, government IDs (SSS, PhilHealth, Pag-IBIG, TIN). Validated setters; `getFullName()` is computed, not stored. Declares `isEligibleForLeaveCredits()`. | parent of `RegularEmployee`, `ProbationaryEmployee` |
| `RegularEmployee` | Adds `leaveCreditsBalance`. Overrides `isEligibleForLeaveCredits()` → `true`. | extends `Employee` |
| `ProbationaryEmployee` | Adds `regularizationDate`. Overrides `isEligibleForLeaveCredits()` → `false`. | extends `Employee` |
| `AttendanceRecord` | Protects raw `timeIn` / `timeOut` (`LocalTime`) for one employee and date; rejects a `timeOut` earlier than `timeIn`; exposes `getHoursWorked()` as a computed value. | used by `PayrollProcessor` |
| `PayrollCalculation` *(abstract)* | The shared shape of any payroll calculation: a `protected isValidAmount(double)` check (rejects negatives) plus an abstract `calculate(...)` each subclass must supply. | parent of `PayrollProcessor`, `ContributionCalculator` |
| `PayrollProcessor` | `calculate(Employee, AttendanceRecord)` → gross pay for one period. | extends `PayrollCalculation` |
| `ContributionCalculator` *(abstract)* | The shape of **one** statutory deduction — validate the salary, then compute that deduction from its own rate table. | extends `PayrollCalculation`; parent of the four below |
| `SssContribution` · `PhilHealthContribution` · `PagIbigContribution` · `WithholdingTaxContribution` | Each overrides `calculate(double)` for its own deduction (SSS bracket table · PhilHealth % with floor/ceiling · Pag-IBIG 1–2% brackets · TRAIN-law tax brackets). | extend `ContributionCalculator` |
| `Payslip` | Immutable holder of `grossPay`, `totalDeductions`, and `netPay` for one period — getters only, no setters once generated. *(The domain object; distinct from the `PayslipScreen` UI window.)* | built from `PayrollProcessor` + the contribution calculators |

### Key methods

| Class | Method | Visibility | Signature | Rule |
|---|---|---|---|---|
| `Employee` | `getFullName` | public | `() → String` | computed from `firstName` + `lastName`; no stored field |
| `Employee` | `setMonthlySalary` | public | `(double) → void` | value must be `> 0` |
| `Employee` | `setHourlyRate` | public | `(double) → void` | rate must be `> 0` |
| `Employee` | `setSssNumber` | public | `(String) → void` | must match the 10-digit SSS format |
| `Employee` | `isValidSalary` | private | `(double) → boolean` | `false` if `≤ 0` |
| `Employee` | `isEligibleForLeaveCredits` | public *(abstract)* | `() → boolean` | resolved by the real subclass at runtime |
| `AttendanceRecord` | `getHoursWorked` | public | `() → double` | `0` if either time is unset |
| `AttendanceRecord` | `setTimeOut` | public | `(LocalTime) → void` | must be later than `timeIn` |
| `PayrollCalculation` | `calculate` | public *(abstract)* | `(…) → double` | subclass supplies the formula |
| `PayrollCalculation` | `isValidAmount` | protected | `(double) → boolean` | `false` if `< 0`; shared by every subclass |
| `PayrollProcessor` | `calculate` | public | `(Employee, AttendanceRecord) → double` | gross pay; rejects null inputs |
| `*Contribution` | `calculate` | public | `(double) → double` | one statutory deduction each |
| `Payslip` | `getNetPay` | public | `() → double` | set once at creation, no setter |

### How the four principles apply

- **Encapsulation** — every payroll field is private; changeable values go through validated
  setters (`setMonthlySalary` / `setHourlyRate` reject non-positive amounts, `setTimeOut` rejects
  a time before `timeIn`); finalized or derived values (`netPay`, `hoursWorked`, `fullName`)
  expose a getter only.
- **Abstraction** — `PayrollCalculation` factors the "validate, then compute" shape out of
  gross-pay and every deduction into one place, so a new payroll or contribution type is a new
  subclass rather than a change to existing code. The `dao` repository interfaces are a second
  abstraction: callers depend on `EmployeeRepository`, not on the CSV files behind it.
- **Inheritance** — `Employee` → `RegularEmployee` / `ProbationaryEmployee`, and
  `PayrollCalculation` → `PayrollProcessor` + the four `ContributionCalculator` subclasses. Each
  subclass inherits the shared fields and the `isValidAmount()` check unchanged and adds only its
  own field or formula.
- **Polymorphism** — `isEligibleForLeaveCredits()` and `calculate()` are called through
  a base-type reference and resolve to the real subclass at runtime. A `List<PayrollCalculation>`
  holding one `PayrollProcessor` and all four contribution objects computes gross pay and every
  deduction in a single loop, with no type checks.

---

## Build & run

**Requirements:** JDK 21 and Apache Ant on the `PATH`.

```bash
# build the jar (also copies the libraries into dist/lib/)
ant clean jar

# run it
ant run
# or directly, from the project root:
java --enable-preview -jar dist/MotorPHPayroll.jar
```

The main class is `LoginScreen1`. `ant run` passes `--enable-preview` automatically; include it
yourself if launching the jar by hand. The `-post-jar` step in `build.xml` copies the vendored
libraries to `dist/lib/` and writes them into the jar's `Class-Path`, so the built jar runs on
its own outside NetBeans. Launch it from the project root so `src/data/` is found.

<details>
<summary>Building without Ant / NetBeans</summary>

```bash
mkdir -p out
javac --enable-preview --release 21 -cp "libs/*" -d out $(find src -name '*.java')
cp -r src/data out/
java --enable-preview -cp "out:libs/*" LoginScreen1
```
</details>

---

## Data files

Stored as CSV under [`src/data/`](src/data/):

| File | Contents |
|------|----------|
| `employee_info.csv` | Employee master records (20 columns: IDs, position, compensation, allowances, birthday) |
| `employee_logins.csv` | Login credentials, role, security question/answer, email |
| `Attendance Record.csv` | Daily log-in / log-out entries per employee |
| `SSS Contribution.csv` | SSS contribution table (compensation range → premium), read at payroll time |

Passwords in `employee_logins.csv` are upgraded from plaintext to a salted PBKDF2 hash the
first time each account logs in successfully.

---

## Security notes

- Passwords: salted PBKDF2-HMAC-SHA256 via `util.PasswordHasher`; legacy plaintext values
  self-migrate on first successful login.
- **Known limitation:** the seed `employee_logins.csv` ships with plaintext demo passwords and
  those values exist in git history. Before this repository is made public or shared with
  anyone outside the team, the history must be scrubbed and any real passwords rotated. See
  [`team-notes/`](team-notes/) for the tracking item.
- The security-question recovery answer in the seed data is a placeholder, not a real
  identity check.

---

## Development

- The **Milestone 1 design package** (CRC cards, method dictionary, architecture overview) is
  maintained in the team's shared design workbook; the section above is a summary of it.
- The **OOP build backlog** — the ordered list of code changes to reach that design — is in
  [`team-notes/2026-09-01-oop-readiness-plan.md`](team-notes/2026-09-01-oop-readiness-plan.md).
- Planning notes and meeting notes live in [`team-notes/`](team-notes/).

**Team roles:** Sumatra — Team Lead (architecture, review, integration) · Paculan — Project
Manager (schedule, submission) · Arriesgado — Design & Documentation Lead (the workbook,
doc↔code consistency) · Grate — Instructor Liaison & QA Lead.

---

## Course context

**MO-IT110 Object-Oriented Programming**, MMDC 2026–2027. Built by **Kainos Enterprise Systems** —
D.R. Sumatra, A. Paculan, M. Arriesgado, N. Grate — for the client MotorPH.

### Project origin

The foundation of this OOP project is the **CP2 payroll system built by Team Petix**
(CP2 H1102, SY 2024–25): **C. Oreta, S. Singh, R. Sisles, J. Singh, and D. Sumatra**.

Of that team, only **D. Sumatra** continues into this course. As an original Team Petix member he
is bringing the CP2 codebase forward as the starting point for this project. The original CP2
repository remains Team Petix's; it is not shared with the current team, who work only on this
derived project.
